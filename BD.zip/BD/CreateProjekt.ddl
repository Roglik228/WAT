--Andrii Godlevskyi



--Tablicy 

CREATE TABLE p_kategorie (
    id_kategorii    NUMBER(3) NOT NULL,
    nazwa_kategorii VARCHAR2(30)
);

ALTER TABLE p_kategorie ADD CONSTRAINT p_kategorie_pk PRIMARY KEY ( id_kategorii );

CREATE TABLE p_klient (
    id_klienta  NUMBER(5) NOT NULL,
    imie        VARCHAR2(30),
    nazwisko    VARCHAR2(30),
    nr_telefonu NUMBER(9),
    email       VARCHAR2(100)
);

ALTER TABLE p_klient ADD CONSTRAINT p_klient_pk PRIMARY KEY ( id_klienta );

CREATE TABLE p_pracownik (
    id_pracownika NUMBER(5) NOT NULL,
    imie          VARCHAR2(30),
    nazwisko      VARCHAR2(30),
    nr_telefonu   NUMBER(9),
    email         VARCHAR2(100)
);

ALTER TABLE p_pracownik ADD CONSTRAINT p_pracownik_pk PRIMARY KEY ( id_pracownika );

CREATE TABLE p_produkt (
    id_produktu    NUMBER(4) NOT NULL,
    nazwa_produktu VARCHAR2(100),
    cena_produktu  NUMBER(5),
    stan_magazynu  NUMBER(5),
    id_kategorii   NUMBER(3) NOT NULL
);

ALTER TABLE p_produkt ADD CONSTRAINT p_produkt_pk PRIMARY KEY ( id_produktu );

CREATE TABLE p_usluga (
    id_uslugi      NUMBER(5) NOT NULL,
    nazwa_uslugi   VARCHAR2(100),
    cena_uslugi    NUMBER(5),
    czas_wykonania NUMBER(4, 2)
);

ALTER TABLE p_usluga ADD CONSTRAINT p_usluga_pk PRIMARY KEY ( id_uslugi );

CREATE TABLE p_wybrane_produkty (
    id_zlecenia    NUMBER(5) NOT NULL,
    id_produktu    NUMBER(4) NOT NULL,
    ilosc_produktu NUMBER(4)
);

ALTER TABLE p_wybrane_produkty ADD CONSTRAINT produkt_zlecenie_pk PRIMARY KEY ( id_zlecenia,
                                                                                id_produktu );

CREATE TABLE p_wybrane_uslugi (
    id_zlecenia NUMBER(5) NOT NULL,
    id_uslugi   NUMBER(5) NOT NULL
);

ALTER TABLE p_wybrane_uslugi ADD CONSTRAINT zlezenie_usluga_pk PRIMARY KEY ( id_zlecenia,
                                                                             id_uslugi );

CREATE TABLE p_zlecenie (
    id_zlecenia              NUMBER(5) NOT NULL,
    data_zlecenia            DATE,
    czas_realizacji_zlecenia NUMBER(4, 2),
    wartosc_zlecenia         NUMBER,
    id_klienta               NUMBER(5) NOT NULL,
    id_pracownika            NUMBER(5) NOT NULL
);

ALTER TABLE p_zlecenie ADD CONSTRAINT p_zlecenie_pk PRIMARY KEY ( id_zlecenia );

ALTER TABLE p_produkt
    ADD CONSTRAINT p_produkt_p_kategorie_fk FOREIGN KEY ( id_kategorii )
        REFERENCES p_kategorie ( id_kategorii );

ALTER TABLE p_zlecenie
    ADD CONSTRAINT p_zlecenie_p_klient_fk FOREIGN KEY ( id_klienta )
        REFERENCES p_klient ( id_klienta );

ALTER TABLE p_zlecenie
    ADD CONSTRAINT p_zlecenie_p_pracownik_fk FOREIGN KEY ( id_pracownika )
        REFERENCES p_pracownik ( id_pracownika );

ALTER TABLE p_wybrane_produkty
    ADD CONSTRAINT produkt_zlecenie_p_produkt_fk FOREIGN KEY ( id_produktu )
        REFERENCES p_produkt ( id_produktu );

ALTER TABLE p_wybrane_produkty
    ADD CONSTRAINT produkt_zlecenie_p_zlecenie_fk FOREIGN KEY ( id_zlecenia )
        REFERENCES p_zlecenie ( id_zlecenia );

ALTER TABLE p_wybrane_uslugi
    ADD CONSTRAINT zlezenie_usluga_p_usluga_fk FOREIGN KEY ( id_uslugi )
        REFERENCES p_usluga ( id_uslugi );

ALTER TABLE p_wybrane_uslugi
    ADD CONSTRAINT zlezenie_usluga_p_zlecenie_fk FOREIGN KEY ( id_zlecenia )
        REFERENCES p_zlecenie ( id_zlecenia );


-- Perspektywy

CREATE OR REPLACE VIEW Przychody AS

SELECT 
    TO_CHAR(z.data_zlecenia, 'YYYY-MM') AS miesiac,
    SUM(p.cena_produktu * wp.ilosc_produktu) AS przychod_z_produktow,
    SUM(u.cena_uslugi) AS przychod_z_uslug,
    SUM(p.cena_produktu * wp.ilosc_produktu) + SUM(u.cena_uslugi) AS laczny_przychod
FROM 
    p_zlecenie z
LEFT JOIN 
    p_wybrane_produkty wp ON z.id_zlecenia = wp.id_zlecenia
LEFT JOIN 
    p_produkt p ON wp.id_produktu = p.id_produktu
LEFT JOIN 
    p_wybrane_uslugi wu ON z.id_zlecenia = wu.id_zlecenia
LEFT JOIN 
    p_usluga u ON wu.id_uslugi = u.id_uslugi
GROUP BY 
    TO_CHAR(z.data_zlecenia, 'YYYY-MM')
ORDER BY 
    miesiac;

/

CREATE OR REPLACE VIEW Najczesciej_wybierane AS

SELECT 
    'Produkt' AS typ, 
    p.nazwa_produktu AS nazwa,
    NVL(SUM(wp.ilosc_produktu), 0) AS liczba_wykorzystan,
    NULL AS czas_wykonania,
    p.stan_magazynu AS aktualny_stan_magazynowy
FROM 
    p_produkt p
LEFT JOIN 
    p_wybrane_produkty wp ON p.id_produktu = wp.id_produktu
GROUP BY 
    p.nazwa_produktu, p.stan_magazynu

UNION ALL

SELECT 
    'Usluga' AS typ, 
    u.nazwa_uslugi AS nazwa,
    COUNT(wu.id_uslugi) AS liczba_wykorzystan,
    AVG(u.czas_wykonania) AS czas_wykonania,
    NULL AS aktualny_stan_magazynowy
FROM 
    p_usluga u
LEFT JOIN 
    p_wybrane_uslugi wu ON u.id_uslugi = wu.id_uslugi
GROUP BY 
    u.nazwa_uslugi;


/

CREATE OR REPLACE VIEW Efektywnosc_pracownikow AS

SELECT 
    p.imie || ' ' || p.nazwisko AS pracownik,
    COUNT(z.id_zlecenia) AS liczba_obsluzonych_zlecen,
    SUM(z.wartosc_zlecenia) AS laczny_przychod
FROM 
    p_zlecenie z
JOIN 
    p_pracownik p ON z.id_pracownika = p.id_pracownika
GROUP BY 
    p.imie, p.nazwisko
ORDER BY 
    laczny_przychod DESC;

/

CREATE OR REPLACE VIEW Stan_i_zuzycie AS

SELECT 
    p.nazwa_produktu,
    p.stan_magazynu AS aktualny_stan_magazynowy,
    NVL(SUM(wp.ilosc_produktu), 0) AS ilosc_zuzyta,
    p.stan_magazynu - NVL(SUM(wp.ilosc_produktu), 0) AS stan_po_zuzyciu
FROM 
    p_produkt p
LEFT JOIN 
    p_wybrane_produkty wp ON p.id_produktu = wp.id_produktu
GROUP BY 
    p.nazwa_produktu, p.stan_magazynu
ORDER BY 
    ilosc_zuzyta DESC, aktualny_stan_magazynowy ASC;

/