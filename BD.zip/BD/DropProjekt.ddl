--Usuwanie perspektyw

DROP VIEW Przychody;

DROP VIEW Najczesciej_wybierane;

DROP VIEW Efektywnosc_pracownikow;

DROP VIEW Stan_i_zuzycie;

--Usuwanie sekwencji


DROP SEQUENCE seq_kategorie;

DROP SEQUENCE seq_produkt;

DROP SEQUENCE seq_usluga;

DROP SEQUENCE seq_klient;

DROP SEQUENCE seq_pracownik;

DROP SEQUENCE seq_zlecenie;

--Usuwanie tablic


DROP TABLE p_kategorie CASCADE CONSTRAINTS;

DROP TABLE p_klient CASCADE CONSTRAINTS;

DROP TABLE p_pracownik CASCADE CONSTRAINTS;

DROP TABLE p_produkt CASCADE CONSTRAINTS;

DROP TABLE p_usluga CASCADE CONSTRAINTS;

DROP TABLE p_wybrane_produkty CASCADE CONSTRAINTS;

DROP TABLE p_wybrane_uslugi CASCADE CONSTRAINTS;

DROP TABLE p_zlecenie CASCADE CONSTRAINTS;
