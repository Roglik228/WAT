-- Sekwencja dla P_Kategorie
CREATE SEQUENCE seq_kategorie
START WITH 1
INCREMENT BY 1
NOCACHE;

-- Sekwencja dla P_Produkt
CREATE SEQUENCE seq_produkt
START WITH 1
INCREMENT BY 1
NOCACHE;

-- Sekwencja dla P_Usluga
CREATE SEQUENCE seq_usluga
START WITH 1
INCREMENT BY 1
NOCACHE;

-- Sekwencja dla P_Klient
CREATE SEQUENCE seq_klient
START WITH 1
INCREMENT BY 1
NOCACHE;

-- Sekwencja dla P_Pracownik
CREATE SEQUENCE seq_pracownik
START WITH 1
INCREMENT BY 1
NOCACHE;

-- Sekwencja dla P_Zlecenie
CREATE SEQUENCE seq_zlecenie
START WITH 1
INCREMENT BY 1
NOCACHE;

-- Tabela P_Kategorie
INSERT INTO P_Kategorie (id_kategorii, nazwa_kategorii) VALUES (seq_kategorie.NEXTVAL, 'Opony');
INSERT INTO P_Kategorie (id_kategorii, nazwa_kategorii) VALUES (seq_kategorie.NEXTVAL, 'Hamulce');
INSERT INTO P_Kategorie (id_kategorii, nazwa_kategorii) VALUES (seq_kategorie.NEXTVAL, 'Olej');
INSERT INTO P_Kategorie (id_kategorii, nazwa_kategorii) VALUES (seq_kategorie.NEXTVAL, 'Silnik');
INSERT INTO P_Kategorie (id_kategorii, nazwa_kategorii) VALUES (seq_kategorie.NEXTVAL, 'Akumulatory');
INSERT INTO P_Kategorie (id_kategorii, nazwa_kategorii) VALUES (seq_kategorie.NEXTVAL, 'Swiatla');

-- Tabela P_Produkt
INSERT INTO P_Produkt (id_produktu, nazwa_produktu, cena_produktu, stan_magazynu, id_kategorii) VALUES (seq_produkt.NEXTVAL, 'Opona letnia', 180.00, 60, 1);
INSERT INTO P_Produkt (id_produktu, nazwa_produktu, cena_produktu, stan_magazynu, id_kategorii) VALUES (seq_produkt.NEXTVAL, 'Opona caloroczna', 250.00, 40, 1);
INSERT INTO P_Produkt (id_produktu, nazwa_produktu, cena_produktu, stan_magazynu, id_kategorii) VALUES (seq_produkt.NEXTVAL, 'Tarcze hamulcowe', 150.00, 80, 2);
INSERT INTO P_Produkt (id_produktu, nazwa_produktu, cena_produktu, stan_magazynu, id_kategorii) VALUES (seq_produkt.NEXTVAL, 'Olej polsyntetyczny', 70.00, 120, 3);
INSERT INTO P_Produkt (id_produktu, nazwa_produktu, cena_produktu, stan_magazynu, id_kategorii) VALUES (seq_produkt.NEXTVAL, 'Uszczelka miski olejowej', 25.00, 90, 3);
INSERT INTO P_Produkt (id_produktu, nazwa_produktu, cena_produktu, stan_magazynu, id_kategorii) VALUES (seq_produkt.NEXTVAL, 'Pasek klinowy', 50.00, 100, 4);
INSERT INTO P_Produkt (id_produktu, nazwa_produktu, cena_produktu, stan_magazynu, id_kategorii) VALUES (seq_produkt.NEXTVAL, 'Akumulator 12V', 300.00, 30, 5);
INSERT INTO P_Produkt (id_produktu, nazwa_produktu, cena_produktu, stan_magazynu, id_kategorii) VALUES (seq_produkt.NEXTVAL, 'Zarowka LED H4', 45.00, 150, 6);
INSERT INTO P_Produkt (id_produktu, nazwa_produktu, cena_produktu, stan_magazynu, id_kategorii) VALUES (seq_produkt.NEXTVAL, 'Reflektor przedni', 400.00, 10, 6);


-- Tabela P_Klient
INSERT INTO P_Klient (id_klienta, imie, nazwisko, nr_telefonu, email) VALUES (seq_klient.NEXTVAL, 'Jan', 'Kowalski', '123456789', 'jan.kowalski@example.com');
INSERT INTO P_Klient (id_klienta, imie, nazwisko, nr_telefonu, email) VALUES (seq_klient.NEXTVAL, 'Anna', 'Nowak', '987654321', 'anna.nowak@example.com');
INSERT INTO P_Klient (id_klienta, imie, nazwisko, nr_telefonu, email) VALUES (seq_klient.NEXTVAL, 'Marek', 'Wisniewski', '456123789', 'marek.wisniewski@example.com');
INSERT INTO P_Klient (id_klienta, imie, nazwisko, nr_telefonu, email) VALUES (seq_klient.NEXTVAL, 'Krzysztof', 'Zalewski', '852369741', 'krzysztof.zalewski@example.com');
INSERT INTO P_Klient (id_klienta, imie, nazwisko, nr_telefonu, email) VALUES (seq_klient.NEXTVAL, 'Maria', 'Szymanska', '963852741', 'maria.szymanska@example.com');

-- Tabela P_Pracownik
INSERT INTO P_Pracownik (id_pracownika, imie, nazwisko, nr_telefonu, email) VALUES (seq_pracownik.NEXTVAL, 'Piotr', 'Malinowski', '741852963', 'piotr.malinowski@example.com');
INSERT INTO P_Pracownik (id_pracownika, imie, nazwisko, nr_telefonu, email) VALUES (seq_pracownik.NEXTVAL, 'Katarzyna', 'Zielinska', '852963741', 'katarzyna.zielinska@example.com');
INSERT INTO P_Pracownik (id_pracownika, imie, nazwisko, nr_telefonu, email) VALUES (seq_pracownik.NEXTVAL, 'Adam', 'Nowicki', '963741852', 'adam.nowicki@example.com');
INSERT INTO P_Pracownik (id_pracownika, imie, nazwisko, nr_telefonu, email) VALUES (seq_pracownik.NEXTVAL, 'Ewa', 'Gorska', '147258369', 'ewa.gorska@example.com');

-- Tabela P_Zlecenie
INSERT INTO P_Zlecenie (id_zlecenia, data_zlecenia, czas_realizacji_zlecenia, wartosc_zlecenia, id_klienta, id_pracownika) VALUES (seq_zlecenie.NEXTVAL, TO_DATE('2025-01-01', 'YYYY-MM-DD'), 1.5, 300.00, 1, 1);
INSERT INTO P_Zlecenie (id_zlecenia, data_zlecenia, czas_realizacji_zlecenia, wartosc_zlecenia, id_klienta, id_pracownika) VALUES (seq_zlecenie.NEXTVAL, TO_DATE('2024-03-02', 'YYYY-MM-DD'), 2.0, 450.00, 2, 2);
INSERT INTO P_Zlecenie (id_zlecenia, data_zlecenia, czas_realizacji_zlecenia, wartosc_zlecenia, id_klienta, id_pracownika) VALUES (seq_zlecenie.NEXTVAL, TO_DATE('2024-09-03', 'YYYY-MM-DD'), 3.0, 600.00, 3, 1);
INSERT INTO P_Zlecenie (id_zlecenia, data_zlecenia, czas_realizacji_zlecenia, wartosc_zlecenia, id_klienta, id_pracownika) VALUES (seq_zlecenie.NEXTVAL, TO_DATE('2025-05-04', 'YYYY-MM-DD'), 1.0, 150.00, 4, 3);
INSERT INTO P_Zlecenie (id_zlecenia, data_zlecenia, czas_realizacji_zlecenia, wartosc_zlecenia, id_klienta, id_pracownika) VALUES (seq_zlecenie.NEXTVAL, TO_DATE('2025-01-05', 'YYYY-MM-DD'), 0.8, 60.00, 5, 4);

--Tabela P_Wybrane_Produkty
INSERT INTO P_Wybrane_Produkty (id_zlecenia, id_produktu, ilosc_produktu) VALUES (1, 1, 4);
INSERT INTO P_Wybrane_Produkty (id_zlecenia, id_produktu, ilosc_produktu) VALUES (1, 3, 1);
INSERT INTO P_Wybrane_Produkty (id_zlecenia, id_produktu, ilosc_produktu) VALUES (2, 2, 1);
INSERT INTO P_Wybrane_Produkty (id_zlecenia, id_produktu, ilosc_produktu) VALUES (2, 4, 1);
INSERT INTO P_Wybrane_Produkty (id_zlecenia, id_produktu, ilosc_produktu) VALUES (3, 5, 4);
INSERT INTO P_Wybrane_Produkty (id_zlecenia, id_produktu, ilosc_produktu) VALUES (4, 7, 1);
INSERT INTO P_Wybrane_Produkty (id_zlecenia, id_produktu, ilosc_produktu) VALUES (5, 8, 2);

-- Tabela P_Usluga
INSERT INTO P_Usluga (id_uslugi, nazwa_uslugi, cena_uslugi, czas_wykonania) VALUES (seq_usluga.NEXTVAL, 'Wymiana opon', 100.00, 1.5);
INSERT INTO P_Usluga (id_uslugi, nazwa_uslugi, cena_uslugi, czas_wykonania) VALUES (seq_usluga.NEXTVAL, 'Wymiana klockow hamulcowych', 150.00, 2.0);
INSERT INTO P_Usluga (id_uslugi, nazwa_uslugi, cena_uslugi, czas_wykonania) VALUES (seq_usluga.NEXTVAL, 'Wymiana oleju', 80.00, 1.0);
INSERT INTO P_Usluga (id_uslugi, nazwa_uslugi, cena_uslugi, czas_wykonania) VALUES (seq_usluga.NEXTVAL, 'Diagnostyka silnika', 200.00, 3.0);
INSERT INTO P_Usluga (id_uslugi, nazwa_uslugi, cena_uslugi, czas_wykonania) VALUES (seq_usluga.NEXTVAL, 'Wymiana akumulatora', 50.00, 0.5);
INSERT INTO P_Usluga (id_uslugi, nazwa_uslugi, cena_uslugi, czas_wykonania) VALUES (seq_usluga.NEXTVAL, 'Regulacja swiatel', 60.00, 0.8);

--Tabela P_Wybrane_Uslugi
INSERT INTO P_Wybrane_Uslugi (id_zlecenia, id_uslugi) VALUES (1, 1);
INSERT INTO P_Wybrane_Uslugi (id_zlecenia, id_uslugi) VALUES (2, 2);
INSERT INTO P_Wybrane_Uslugi (id_zlecenia, id_uslugi) VALUES (3, 3);
INSERT INTO P_Wybrane_Uslugi (id_zlecenia, id_uslugi) VALUES (4, 5);
INSERT INTO P_Wybrane_Uslugi (id_zlecenia, id_uslugi) VALUES (5, 6);