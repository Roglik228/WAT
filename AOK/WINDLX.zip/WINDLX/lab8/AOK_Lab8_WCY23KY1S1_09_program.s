.data

T: .space 1040
TB: .space 864
Suma: .double 0.0
skladnik: .double 1880
ulamek: .double 0.88
jeden: .double 1.0
stala: .double 8.8
nr: .double 9.0
rozmiar: .word 108
rozmiarT: .word 130

.text

addi r1, r0, T
addi r2, r0, TB
ld f2, skladnik
ld f4, ulamek
ld f8, nr
ld f10, jeden
lw r4, rozmiarT

addd f6, f2, f4
addd f6, f6, f8

petla1:
sd 0(r1), f6
addd f6, f6, f10
addi r1, r1, #8
subi r4, r4, #1

bnez r4, petla1

addi r1, r0, T
addi r2, r0, TB

lw r3, rozmiar

ld f14, stala

petla2:

ld f2, 0(r1)
ld f6, 8(r1)
ld f8, 16(r1)
ld f10, 24(r1)
ld f12, 32(r1)

addd f16, f2, f6
multd f16, f16, f14 
addd f18, f8, f10
multd f18, f18, f12
multd f16, f16, f18
divd f16, f16, f10

sd 0(r2), f16
addd f20, f20, f16
addi r1, r1, #8
addi r2, r2, #8
subi r3, r3, #1
bnez r3, petla2

sd Suma, f20

trap 0


;TB[0]=[8.8*(1889,88+1890,88)*(1891,88+1892,88)*1893,88]/[1892,88]
;TB[107]=[8.8*(1996,88+1997,88)*(1998,88+1999,88)*2000,88]/[1999,88]