.data

T: .space 520
TB: .space 420
Suma: .float 0.0
skladnik: .float 50
jeden: .float 1.0
stala: .float 5.0
nr: .float 9.0
rozmiar: .word 105
rozmiarT: .word 130

.text

addi r1, r0, T
addi r2, r0, TB
lf f2, skladnik
;lf f4, ulamek
lf f8, nr
lf f10, jeden
lw r4, rozmiarT

;addf f6, f2, f4
addf f6, f2, f8

petla1:
sd 0(r1), f6
addf f6, f6, f10
addi r1, r1, #8
subi r4, r4, #1

bnez r4, petla1

addi r1, r0, T
addi r2, r0, TB

lw r3, rozmiar

lf f14, stala

petla2:


lf f2, 0(r1)
lf f6, 4(r1)
lf f8, 8(r1)
lf f9, 12(r1)


multf f16, f2, f14
multf f16, f16, f6 
multf f16, f16, f8

divf f16, f16, f9

sd 0(r2), f16
addf f20, f20, f16
addi r1, r1, #4
addi r2, r2, #4
subi r3, r3, #1
bnez r3, petla2

sd Suma, f20

trap 0


;TB[0]=5*59*60*61/62=17414,52

;TB[104]=5*163*164*165/166=132854,82

