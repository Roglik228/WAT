.data 

TA: .space 560
TB: .space 520
rozmiar_ta: .word 140
rozmiar_tb: .word 130
Suma: .double 0.0
stala: .word 9

.text

addi r1, r0, TA
addi r2, r0, #140
lw r20, stala

petla1:
addi r4, r20, #2200
add r5, r4, r0
sw 0(r1), r5

addi r1, r1, #4
addi r20, r20, #1
subi r2, r2, #1
bnez r2, petla1

addi r1, r0, TA
addi r6, r0, TB

lw r7, rozmiar_ta
lw r8, rozmiar_tb
addi r13, r0, #6

petla2:
lw r10, 4(r1)
lw r11, 8(r1)
lw r12, 20(r1)

add r10 ,r10, r11
add r10 ,r10, r12
mult r10, r10, r13

sw 0(r6), r10

addi r1, r1, #4
addi r6, r6, #4
subi r8, r8, #1
bnez r8, petla2

addi r6, r0 ,TB
lw r8, rozmiar_tb
lw r9, #0

SUMA:
lw r15, 0(r6)
add r9, r9, r15

addi r6, r6, #4
subi r8, r8, #1
bnez r8, SUMA

movi2fp f1, r9
cvti2d f6, f1
sd Suma, f6


trap 0;


;TB[0]= (2235+2232+2231)6=39810
;TB[129]=(2364+2361+2360)6=42132