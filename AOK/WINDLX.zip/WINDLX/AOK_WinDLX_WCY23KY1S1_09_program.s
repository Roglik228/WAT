.data 

T: .space 800
TB: .space 760
Suma: .word 0
rozmiarT: .word 200
rozmiarTB: .word 190
stala: .word 9

.text

addi r1,r0,T
addi r2,r0,#200
lw r20,stala

petla1:
addi r4,r20,#100
add r5,r4,r0
sw 0(r1),r5

addi r1,r1,#4
addi r20,r20,#1
subi r2,r2,#1
bnez r2,petla1

addi r1,r0,T
addi r6,r0,TB

lw r7,rozmiarT
lw r8,rozmiarTB
addi r13,r0,#5

petla2:
lw r20,0(r1)
lw r10,4(r1)
lw r11,8(r1)
lw r21,12(r1)
lw r12,20(r1)

mult r17,r13,r20
mult r17,r17,r10
mult r17,r17,r11

mult r19,r21,r12
div r17,r17,r19

sw 0(r6),r17

addi r1,r1,#4
addi r6,r6,#4
subi r8,r8,#1
bnez r8,petla2

addi r6,r0,TB
lw r8,rozmiarTB

add r14, r0, r0 

suma:
lw r9,0(r6)
add r14,r14,r9

addi r6,r6,#4
subi r8,r8,#1

bnez r8,suma

sw Suma,r14


trap 0


;TB[0]=(5*109*110*111)/(112*114)=521
;Tb[189]=(5*298*299*300)/(301*303)=1465