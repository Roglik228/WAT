.data
k:        .word 0
nr:       .word 9
stala:    .word 9
rozmiar:  .word 10
wektor:   .word 109, 119, 129, 139, 149, 159, 169, 179, 189, 199
suma1:    .word 0
.text

main:
        lw   r1, rozmiar(r0)
        addi r2, r0, wektor
        addi r9, r0, 0

loop_suma1:
        lw   r3, 0(r2)
        add  r6, r6, r3
        addi r2, r2, 4
        sub  r1, r1, 1
        bnez r1, loop_suma1

        sw   suma1, r9

        lw   r1, rozmiar(r0)
        addi r2, r0, wektor
        addi r7, r0, 0
        lw   r5, stala(r0)

loop_suma2:
        lw   r3, 0(r2)
        add  r3, r3, r5
        sw   0(r2), r3
        add  r7, r7, r3
        addi r2, r2, 4
        sub  r1, r1, 1
        bnez r1, loop_suma2

        sw   suma2, r7
        sub  r8, r7, r6
        sw   roznica, r8
        lw   r1, rozmiar(r0)
        mult  r9, r1, r5
        sw   iloczyn, r9

trap 0
