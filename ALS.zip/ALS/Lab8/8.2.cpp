///Godlevskyi Andrii
///Zadanie 2 z laboratorium 8


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>

// Funkcja do odczytu danych z pliku
int *odczytaj(const char *filename, int *rozmiar) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Nie mozna otworzyc pliku");
        return NULL;
    }

    int pojemnosc = 10;
    int *data = (int *)malloc(pojemnosc * sizeof(int));
    if (!data) {
        perror("Blad alokacji pamieci");
        fclose(file);
        return NULL;
    }

    *rozmiar = 0;
    int wartosc;
    while (fscanf(file, "%d", &wartosc) == 1) {
        if (*rozmiar >= pojemnosc) {
            pojemnosc *= 2;
            int *new_data = (int *)realloc(data, pojemnosc * sizeof(int));
            if (!new_data) {
                perror("Blad relokacji pamieci");
                free(data);
                fclose(file);
                return NULL;
            }
            data = new_data;
        }
        data[*rozmiar] = wartosc;
        (*rozmiar)++;
    }

    fclose(file);
    return data;
}

// Funkcja do zapisu danych do pliku
void zapisz(const char* filename, int* data, int rozmiar) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        perror("Blad otwarcia pliku");
        return;
    }
    for (int i = 0; i < rozmiar; i++) {
        fprintf(file, "%6d", data[i]);
        if ((i + 1) % 10 == 0) fprintf(file, "\n");
    }
    if (rozmiar % 10 != 0) fprintf(file, "\n");
    fclose(file);
}

// Funkcja pomocnicza do wypisania danych na ekranie
void wypisz(int *data, int rozmiar) {
    for (int i = 0; i < rozmiar; i++) {
        printf("%6d ", data[i]);
        if ((i + 1) % 10 == 0) {
            printf("\n");
        }
    }
    if (rozmiar % 10 != 0) {
        printf("\n");
    }
}

//funkcja Library Sort
void librSort(int *array, int rozmiar) {
    int pojemnosc = rozmiar * 2; // Powiekszona tablica pomocnicza
    int *bufor = (int *)malloc(pojemnosc * sizeof(int));
    if (!bufor) {
        perror("Blad alokacji pamieci dla bufora");
        return;
    }

    // Wypelnienie bufora wartosciami INT_MAX
    for (int i = 0; i < pojemnosc; i++) {
        bufor[i] = INT_MAX;
    }

    // Inicjalizacja - pierwsza liczba trafia na srodek
    bufor[pojemnosc / 2] = array[0];
    int num_elements = 1;

    for (int i = 1; i < rozmiar; i++) {
        int key = array[i];

        // Wyszukiwanie miejsca w buforze dla klucza
        int pierwszy = 0;
        int ostatni = pojemnosc;
        while (pierwszy < ostatni) {
            int mid = (pierwszy + ostatni) / 2;
            if (bufor[mid] == INT_MAX || bufor[mid] >= key) {
                ostatni = mid;
            } else {
                pierwszy = mid + 1;
            }
        }

        // Wstawianie klucza w odpowiednie miejsce
        if (bufor[pierwszy] != INT_MAX) {
            for (int *ptr = &bufor[pojemnosc - 1]; ptr > &bufor[pierwszy]; ptr--) {
                *ptr = *(ptr - 1);
            }
        }
        bufor[pierwszy] = key;
        num_elements++;

        // Rozszerzenie bufora, jesli jest zbyt pelny
        if (num_elements > pojemnosc / 2) {
            int new_pojemnosc = pojemnosc * 2;
            int *new_bufor = (int *)malloc(new_pojemnosc * sizeof(int));
            if (!new_bufor) {
                perror("Blad alokacji pamieci dla nowego bufora");
                free(bufor);
                return;
            }

            for (int i = 0; i < new_pojemnosc; i++) {
                new_bufor[i] = INT_MAX;
            }

            for (int i = 0, j = new_pojemnosc / 4; i < pojemnosc; i++) {
                if (bufor[i] != INT_MAX) {
                    new_bufor[j] = bufor[i];
                    j += 2;
                }
            }

            free(bufor);
            bufor = new_bufor;
            pojemnosc = new_pojemnosc;
        }
    }

    // Przepisanie posortowanych wartosci do tablicy wejsciowej
    int index = 0;
    for (int i = 0; i < pojemnosc; i++) {
        if (bufor[i] != INT_MAX) {
            array[index++] = bufor[i];
        }
    }

    free(bufor);
}

//Glowna funkcja
int main() {
    int wybor, rozmiar=0, *data=NULL;

    printf("Wybierz zrodlo danych:\n");
    printf("1. Generacja losowych wartosci\n");
    printf("2. Odczyt z pliku (we.txt)\n");
    printf("3. Wpisanie z klawiatury\n");
    printf("Wybor: ");
    scanf("%d", &wybor);

    if (wybor == 1) {
        printf("Wpisz ilosc liczb do generacji: ");
        int n;
        scanf("%d", &n);
        int min=1;
		int max=999;
        data = (int*)malloc(n * sizeof(int));
        if (!data) {
            perror("Blad alokacji pamieci");
            return 1;
        }
        srand(time(0));
        for (int i = 0; i < n; i++) {
            data[i] = min + rand() % (max - min + 1);
        }
        rozmiar = n;
    } else if (wybor == 2) {
        data = odczytaj("we.txt", &rozmiar);
        if (!data) {
            return 1;
        }
    } else if (wybor == 3) {
        printf("Wpisz liczby do sortowania(aby skonczyc wpisz nie liczbe)\n");
        int liczba;
        while (scanf("%d", &liczba) == 1) {
            data = (int*)realloc(data, (rozmiar + 1) * sizeof(int));
            if (!data) {
                perror("Error reallocating memory");
                return 1;
            }
            data[rozmiar++] = liczba;
        }
        while (getchar() != '\n'); 
    } else {
        fprintf(stderr, "Zly wybor.\n");
        return 1;
    }
//Wypisanie i zapisanie danych
    printf("Dane do sortowania:\n");
    wypisz(data, rozmiar);

    librSort(data, rozmiar);

    printf("Dane po sortowaniu:\n");
    wypisz(data, rozmiar);

    zapisz("wy.txt", data, rozmiar);

    free(data);
    return 0;
}

