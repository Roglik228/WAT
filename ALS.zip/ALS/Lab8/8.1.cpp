///Godlevskyi Andrii
///Zadanie 1 z laboratorium 8


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Sortowanie Shell
void shellSort(int* arr, int n) {
    for (int gap = n / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < n; i++) {
            int temp = arr[i];
            int j;
            for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                arr[j] = arr[j - gap];
            }
            arr[j] = temp;
        }
    }
}

//Wypisanie liczb po 10
void wypisz(int* arr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%6d", arr[i]);
        if ((i + 1) % 10 == 0) printf("\n");
    }
    if (n % 10 != 0) printf("\n");
}

//Funkcja do odczytu danych z pliku
int* odczytaj(const char* filename, int* rozmiar) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("Blad otwarcia pliku");
        return NULL;
    }
    int* data = NULL;
    int liczba, licznik = 0;
    while (fscanf(file, "%d", &liczba) == 1) {
        data = (int*)realloc(data, (licznik + 1) * sizeof(int));
        if (!data) {
            perror("Blad relokacji pamieci");
            fclose(file);
            return NULL;
        }
        data[licznik++] = liczba;
    }
    fclose(file);
    *rozmiar = licznik;
    return data;
}

//Funkcja do zapisu danych do pliku
void zapisz(const char* filename, int* data, int rozmiar) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        perror("Blad otwarcia pliku");
        return;
    }
    for (int i = 0; i < rozmiar; i++) {
        fprintf(file, "%6d", data[i]);
        if ((i + 1) % 10 == 0) fprintf(file, "\n");
    }
    if (rozmiar % 10 != 0) fprintf(file, "\n");
    fclose(file);
}

//Glowna funkcja
int main() {
    int* data = NULL;
    int rozmiar = 0;

    printf("Wybierz opcje:\n");
    printf("1. Generacja losowych wartosci\n");
    printf("2. Odczyt z pliku (we.txt)\n");
    printf("3. Wpisanie z klawiatury\n");
    int wybor;
    printf("Twoj wybor: ");
    scanf("%d", &wybor);

    if (wybor == 1) {
        printf("Wpisz ilosc liczb do generacji: ");
        int n;
        scanf("%d", &n);
        int min=1;
		int max=999;
        data = (int*)malloc(n * sizeof(int));
        if (!data) {
            perror("Blad alokacji pamieci");
            return 1;
        }
        srand(time(0));
        for (int i = 0; i < n; i++) {
            data[i] = min + rand() % (max - min + 1);
        }
        rozmiar = n;
    } else if (wybor == 2) {
        data = odczytaj("we.txt", &rozmiar);
        if (!data) {
            return 1;
        }
    } else if (wybor == 3) {
        printf("Wpisz liczby do sortowania(aby skonczyc wpisz nie liczbe)\n");
        int liczba;
        while (scanf("%d", &liczba) == 1) {
            data = (int*)realloc(data, (rozmiar + 1) * sizeof(int));
            if (!data) {
                perror("Error reallocating memory");
                return 1;
            }
            data[rozmiar++] = liczba;
        }
        while (getchar() != '\n'); 
    } else {
        fprintf(stderr, "Zly wybor.\n");
        return 1;
    }
//Wypisanie i zapisanie danych
    printf("Dane do sortowania:\n");
    wypisz(data, rozmiar);

    shellSort(data, rozmiar);

    printf("Dane po sortowaniu:\n");
    wypisz(data, rozmiar);

    zapisz("wy.txt", data, rozmiar);

    free(data);
    return 0;
}

