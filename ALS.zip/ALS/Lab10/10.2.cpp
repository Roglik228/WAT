/// Godlevskyi Andrii
/// Zadanie 2 z laboratorium 10

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

// Funkcja do podzialu danych na dwa pliki pomocnicze
void podzielNaSerie(const string &plikWe, const string &plikPom1, const string &plikPom2) {
    ifstream wejscie(plikWe.c_str());
    ofstream pomoc1(plikPom1.c_str());
    ofstream pomoc2(plikPom2.c_str());

    if (!wejscie || !pomoc1 || !pomoc2) {
        cerr << "Blad otwarcia plikow!" << endl;
        return;
    }

    int poprzednia, aktualna;
    bool doPom1 = true;

    wejscie >> poprzednia;
    while (wejscie >> aktualna) {
        if (doPom1)
            pomoc1 << poprzednia << endl;
        else
            pomoc2 << poprzednia << endl;

        if (aktualna < poprzednia)
            doPom1 = !doPom1;

        poprzednia = aktualna;
    }

    if (doPom1)
        pomoc1 << poprzednia << endl;
    else
        pomoc2 << poprzednia << endl;

    wejscie.close();
    pomoc1.close();
    pomoc2.close();
}

// Funkcja do laczenia serii z dwoch plikow pomocniczych
void scalSerie(const string &plikPom1, const string &plikPom2, const string &plikWe) {
    ifstream pomoc1(plikPom1.c_str());
    ifstream pomoc2(plikPom2.c_str());
    ofstream wyjscie(plikWe.c_str());

    if (!pomoc1 || !pomoc2 || !wyjscie) {
        cerr << "Blad otwarcia plikow!" << endl;
        return;
    }

    int val1, val2;
    bool koniec1 = !(pomoc1 >> val1);
    bool koniec2 = !(pomoc2 >> val2);

    while (!koniec1 || !koniec2) {
        if (!koniec1 && (koniec2 || val1 <= val2)) {
            wyjscie << val1 << endl;
            if (!(pomoc1 >> val1))
                koniec1 = true;
        } else {
            wyjscie << val2 << endl;
            if (!(pomoc2 >> val2))
                koniec2 = true;
        }
    }

    pomoc1.close();
    pomoc2.close();
    wyjscie.close();
}

// Funkcja sortujaca metoda laczenia naturalnego
void naturalMergeSort(const string &plikWe) {
    const string plikPom1 = "pom1.txt";
    const string plikPom2 = "pom2.txt";

    while (true) {
        podzielNaSerie(plikWe, plikPom1, plikPom2);

        ifstream pomoc1(plikPom1.c_str());
        ifstream pomoc2(plikPom2.c_str());

        bool pusty1 = pomoc1.peek() == EOF;
        bool pusty2 = pomoc2.peek() == EOF;

        pomoc1.close();
        pomoc2.close();

        if (pusty1 || pusty2) {
            break;
        }

        scalSerie(plikPom1, plikPom2, plikWe);
    }
}

// Funkcja do wyswietlania liczb z pliku z wyrownaniem i po 10 w wierszu
void wyswietlZPliku(const string &plik) {
    ifstream wejscie(plik.c_str());

    if (!wejscie) {
        cerr << "Blad otwarcia pliku!" << endl;
        return;
    }

    int liczba;
    int licznik = 0;

    while (wejscie >> liczba) {
        cout << setw(5) << liczba;
        licznik++;

        if (licznik == 10) {
            cout << endl;
            licznik = 0;
        }
    }

    if (licznik != 0) {
        cout << endl;
    }

    wejscie.close();
}

int main() {

    cout<<"Dane sa wczytywane z pliku we50.txt"<<endl;

    const string plikWe = "we50.txt";

    cout << "Dane przed sortowaniem:" << endl;
    wyswietlZPliku(plikWe);

    naturalMergeSort(plikWe);

    cout << "Dane po sortowaniu:" << endl;
    wyswietlZPliku(plikWe);

    return 0;
}

