/// Godlevskyi Andrii
/// Zadanie 1 z laboratorium 10

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void merge(int* data, int left, int middle, int right) {
    int n1 = middle - left + 1;
    int n2 = right - middle;

    int* leftPart = (int*)malloc(n1 * sizeof(int));
    int* rightPart = (int*)malloc(n2 * sizeof(int));

    for (int i = 0; i < n1; ++i) {
        leftPart[i] = data[left + i];
    }
    for (int j = 0; j < n2; ++j) {
        rightPart[j] = data[middle + 1 + j];
    }

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (leftPart[i] <= rightPart[j]) {
            data[k] = leftPart[i];
            i++;
        } else {
            data[k] = rightPart[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        data[k] = leftPart[i];
        i++;
        k++;
    }
    while (j < n2) {
        data[k] = rightPart[j];
        j++;
        k++;
    }

    free(leftPart);
    free(rightPart);
}

void mergeSort(int* data, int left, int right) {
    if (left < right) {
        int middle = left + (right - left) / 2;
        mergeSort(data, left, middle);
        mergeSort(data, middle + 1, right);
        merge(data, left, middle, right);
    }
}

// Wypisanie liczb po 10
void wypisz(int* arr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%6d", arr[i]);
        if ((i + 1) % 10 == 0) printf("\n");
    }
    if (n % 10 != 0) printf("\n");
}

// Funkcja do odczytu danych z pliku
int* odczytaj(const char* filename, int* rozmiar) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("Blad otwarcia pliku");
        return NULL;
    }
    int* data = NULL;
    int liczba, licznik = 0;
    while (fscanf(file, "%d", &liczba) == 1) {
        int* newData = (int*)realloc(data, (licznik + 1) * sizeof(int));
        if (!newData) {
            perror("Blad relokacji pamieci");
            free(data);
            fclose(file);
            return NULL;
        }
        data = newData;
        data[licznik++] = liczba;
    }
    fclose(file);
    *rozmiar = licznik;
    return data;
}

// Funkcja do zapisu danych do pliku
void zapisz(const char* filename, int* data, int rozmiar) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        perror("Blad otwarcia pliku");
        return;
    }
    for (int i = 0; i < rozmiar; i++) {
        fprintf(file, "%6d", data[i]);
        if ((i + 1) % 10 == 0) fprintf(file, "\n");
    }
    if (rozmiar % 10 != 0) fprintf(file, "\n");
    fclose(file);
}

int main() {
    int* data = NULL;
    int rozmiar = 0;

    printf("Wybierz opcje:\n");
    printf("1. Generacja losowych wartosci\n");
    printf("2. Odczyt z pliku (we50.txt)\n");
    printf("3. Wpisanie z klawiatury\n");
    printf("Twoj wybor: ");

    int wybor;
    scanf("%d", &wybor);

    switch (wybor) {
        case 1: {
            printf("Wpisz ilosc liczb do generacji: ");
            int n;
            scanf("%d", &n);
            int min = 1;
            int max = 999;
            data = (int*)malloc(n * sizeof(int));
            if (!data) {
                perror("Blad alokacji pamieci");
                return 1;
            }
            srand(time(0));
            for (int i = 0; i < n; i++) {
                data[i] = min + rand() % (max - min + 1);
            }
            rozmiar = n;
            break;
        }
        case 2: {
            data = odczytaj("we50.txt", &rozmiar);
            if (!data) {
                return 1;
            }
            break;
        }
        case 3: {
            printf("Wpisz liczby do sortowania (aby skonczyc wpisz nie-liczbe):\n");
            int liczba;
            while (scanf("%d", &liczba) == 1) {
                int* newData = (int*)realloc(data, (rozmiar + 1) * sizeof(int));
                if (!newData) {
                    perror("Error reallocating memory");
                    free(data);
                    return 1;
                }
                data = newData;
                data[rozmiar++] = liczba;
            }
            while (getchar() != '\n');
            break;
        }
        default: {
            fprintf(stderr, "Zly wybor.\n");
            return 1;
        }
    }

    // Wypisanie i zapisanie danych PRZED sortowaniem
    printf("Dane do sortowania:\n");
    wypisz(data, rozmiar);

    // Wywolanie mergeSort 
    mergeSort(data, 0, rozmiar - 1);

    // Wypisanie i zapisanie danych PO sortowaniu
    printf("Dane po sortowaniu:\n");
    wypisz(data, rozmiar);

    zapisz("wy.txt", data, rozmiar);

    free(data);
    return 0;
}

