#include <iostream>
#include <cstdio>

using namespace std;

int main() {
    int N, M, K;

    // Otwieranie pliku wejsciowego
    FILE *inputFile = fopen("we.txt", "r");
    if (!inputFile) {
        fprintf(stderr, "Nie mo�na otworzyc pliku we.txt\n");
        return 1;
    }

    // Odczytanie rozmiarow macierzy
    fscanf(inputFile, "%d %d %d", &N, &M, &K);

    // Tworzenie macierzy jako tablice statyczne
    int A[100][100]; // Zak�adamy maksymalne rozmiary macierzy
    int B[100][100];
    int C[100][100] = {0}; // Macierz wynikowa

    // Odczytanie macierzy A
    printf("Macierz A (%dx%d):\n", N, M);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            fscanf(inputFile, "%d", &A[i][j]);
            printf("%d ", A[i][j]);
        }
        printf("\n");
    }

    // Odczytanie macierzy B
    printf("Macierz B (%dx%d):\n", M, K);
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < K; j++) {
            fscanf(inputFile, "%d", &B[i][j]);
            printf("%d ", B[i][j]);
        }
        printf("\n");
    }

    fclose(inputFile);

    // Mno�enie macierzy A i B
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < K; j++) {
            for (int k = 0; k < M; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }

    // Wyswietlenie macierzy wynikowej
    printf("Macierz C (Wynik A * B):\n");
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < K; j++) {
            printf("%d ", C[i][j]);
        }
        printf("\n");
    }

    // Zapisanie wynikow do pliku
    FILE *outputFile = fopen("we.txt", "a"); // Otworz plik w trybie dopisywania

    fprintf(outputFile, "Macierz C (Wynik A * B):\n");
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < K; j++) {
            fprintf(outputFile, "%d ", C[i][j]);
        }
        fprintf(outputFile, "\n");
    }

    fclose(outputFile);
    return 0;
}

