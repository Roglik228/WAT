#include <cstdio>

// Funkcja iteracyjna
unsigned long long silniait(int n) {
    unsigned long long wynik = 1;
    for (int i = 1; i <= n; ++i) {
        wynik *= i;
    }
    return wynik;
}

// Funkcja rekurencyjna 
unsigned long long silniarek(int n) {
    if (n <= 1) {
        return 1;
    }
    return n * silniarek(n - 1);
}

int main() {
    int liczba;
    printf("Podaj liczbe: ");
    scanf("%d", &liczba);
        printf("Silnia (iteracyjnie) z %d to: %llu\n", liczba, silniait(liczba));
        printf("Silnia (rekurencyjnie) z %d to: %llu\n", liczba, silniarek(liczba));

    return 0;
}

