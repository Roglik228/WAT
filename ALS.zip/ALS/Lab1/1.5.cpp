#include <cstdio>
#include <cstdlib> // dla funkcji rand i srand
#include <ctime>   // dla funkcji time

int main() {
    int n, a, b;

    // Odczytanie danych wejsciowych
    printf("Podaj liczbe elementow wektora n: ");
    scanf("%d", &n);
    printf("Podaj dolna granice losowania a: ");
    scanf("%d", &a);
    printf("Podaj gorna granice losowania b: ");
    scanf("%d", &b);

    // Inicjalizacja generatora liczb pseudolosowych
    srand(time(0));

    int *X = new int[n]; // dynamiczna alokacja tablicy X
    int minVal, maxVal;

    // Wypelnienie wektora liczbami losowymi z zakresu <a, b> i znalezienie min oraz max
    for (int i = 0; i < n; i++) {
        X[i] = a + rand() % (b - a + 1);
        if (i == 0) {
            minVal = maxVal = X[i];
        } else {
            if (X[i] < minVal) minVal = X[i];
            if (X[i] > maxVal) maxVal = X[i];
        }
    }

    // Wyswietlenie wektora w wierszach po 10 liczb, wyrownanych do prawej
    printf("\nWektor X:\n");
    for (int i = 0; i < n; i++) {
        printf("%5d", X[i]); // wyrownanie do prawej, szerokosc 5
        if ((i + 1) % 10 == 0) printf("\n"); // nowa linia po 10 liczbach
    }
    printf("\n");

    // Wyswietlenie wartosci minimalnej i maksymalnej
    printf("\nWartosc minimalna: %d\n", minVal);
    printf("Wartosc maksymalna: %d\n", maxVal);

    // Zwolnienie pami�ci
    delete[] X;

    return 0;
}

