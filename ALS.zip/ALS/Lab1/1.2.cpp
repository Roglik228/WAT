#include <cstdio>
#include <cstdlib> // dla funkcji exit
#include <fstream> // dla obslugi plikow

// Funkcja iteracyjna 
unsigned long long fiboit(int n) {
    if (n==0) return 0;
    if (n==1) return 1;

    unsigned long long a = 0, b = 1, c;
    for (int i=2; i<=n; ++i) {
        c = a+b;
        a = b;
        b = c;
    }
    return b;
}

// Funkcja rekurencyjna 
unsigned long long fiborek(int n) {
    if (n == 0) return 0;
    if (n == 1) return 1;
    return fiborek(n - 1) + fiborek(n - 2);
}

int main() {
    int n;
    printf("Podaj liczbe wyrazow: ");
    scanf("%d", &n);

    // Otwarcie pliku do zapisu
    FILE* plik = fopen("wy.txt", "w");

    // Iteracyjna metoda obliczenia ci�gu Fibonacciego
    printf("Iteracyjnie:\n");
    fprintf(plik, "Iteracyjnie:\n");
    for (int i = 0; i < n; ++i) {
        unsigned long long wynik = fiboit(i);
        printf("%llu ", wynik);
        fprintf(plik, "%llu ", wynik);
    }
    printf("\n");
    fprintf(plik, "\n");

    // Rekurencyjna metoda obliczenia ci�gu Fibonacciego
    printf("Rekurencyjnie:\n");
    fprintf(plik, "Rekurencyjnie:\n");
    for (int i = 0; i < n; ++i) {
        unsigned long long wynik = fiborek(i);
        printf("%llu ", wynik);
        fprintf(plik, "%llu ", wynik);
    }
    printf("\n");
    fprintf(plik, "\n");

    fclose(plik);
    return 0;
}

