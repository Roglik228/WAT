#include <cstdio>

// Klasyczna metoda obliczania 
double klas(double a0, double a1, double a2, double x) {
    return a2*x*x+a1*x+a0;
}

// Metoda Hornera
double horn(double a0, double a1, double a2, double x) {
    return (a2*x+a1)*x + a0;
}

int main() {
    double a0, a1, a2, x;

    // Wczytywanie wspolczynnikow i wartosci x
    printf("Podaj a0: ");
    scanf("%lf", &a0);
    printf("Podaj a1: ");
    scanf("%lf", &a1);
    printf("Podaj a2: ");
    scanf("%lf", &a2);
    printf("Podaj wartosc x: ");
    scanf("%lf", &x);

    // Obliczenie wartosci wielomianu klasycznie
    double wynikklas = klas(a0, a1, a2, x);
    printf("Wartosc wielomianu metoda klasyczna: %lf\n", wynikklas);

    // Obliczenie wartosci wielomianu metoda Hornera
    double wynikhorn = horn(a0, a1, a2, x);
    printf("Wartosc wielomianu metoda Hornera: %lf\n", wynikhorn);

    return 0;
}

