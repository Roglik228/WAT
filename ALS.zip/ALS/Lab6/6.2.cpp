///Godlevskyi Andrii
///Zadanie 2 z laboratoium 6

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <fstream>

using namespace std;

// Struktura drzewa
struct Wezel {
    int klucz;
    Wezel* lewy;
    Wezel* prawy;
};

// Tworzenie nowego wezla
Wezel* stworzWezel(int wartosc) {
    Wezel* nowyWezel = (Wezel*)malloc(sizeof(Wezel));  // Uzywamy malloc
    if (nowyWezel == NULL) {
        cout << "Bl�d alokacji pamieci!\n";
        exit(1);  // Zakonczenie programu w przypadku niepowodzenia alokacji
    }
    nowyWezel->klucz = wartosc;
    nowyWezel->lewy = NULL;
    nowyWezel->prawy = NULL;
    return nowyWezel;
}

// Usuwanie calego drzewa
void usunCale(Wezel* korzen) {
    if (korzen == NULL) return;
    usunCale(korzen->lewy);
    usunCale(korzen->prawy);
    free(korzen); 
}

// Przywracanie wlasnosci kopca
void przywrocKopiec(Wezel* korzen) {
    if (!korzen) return;

    Wezel* najwiekszy = korzen;
    if (korzen->lewy && korzen->lewy->klucz > najwiekszy->klucz) {
        najwiekszy = korzen->lewy;
    }

    if (korzen->prawy && korzen->prawy->klucz > najwiekszy->klucz) {
        najwiekszy = korzen->prawy;
    }

    if (najwiekszy != korzen) {
        swap(korzen->klucz, najwiekszy->klucz);
        przywrocKopiec(najwiekszy);
    }
}

// Wysokosc drzewa
int wysokosc(Wezel* korzen) {
    if (korzen == NULL) return 0;
    return 1 + max(wysokosc(korzen->lewy), wysokosc(korzen->prawy));
}

// Dodawanie do drzewa kopca
void dodaj(Wezel*& korzen, int wartosc) {
    if (korzen == NULL) {
        korzen = stworzWezel(wartosc);
        return;
    }

    if (!korzen->lewy) {
        korzen->lewy = stworzWezel(wartosc);
        przywrocKopiec(korzen);
    } else if (!korzen->prawy) {
        korzen->prawy = stworzWezel(wartosc);
        przywrocKopiec(korzen);
    } else {
        if (wysokosc(korzen->lewy) <= wysokosc(korzen->prawy)) {
            dodaj(korzen->lewy, wartosc);
        } else {
            dodaj(korzen->prawy, wartosc);
        }
        przywrocKopiec(korzen);
    }
}

// Usuwanie maksymalnego elementu
void usunMaks(Wezel*& korzen) {
    if (korzen == NULL) {
        cout << "Kopiec jest pusty.\n";
        return;
    }

    cout << "Usuwanie maksymalnego elementu: " << korzen->klucz << endl;
    Wezel* temp = korzen;
    Wezel* rodzic = NULL;

    while (temp->lewy || temp->prawy) {
        rodzic = temp;
        temp = temp->prawy ? temp->prawy : temp->lewy;
    }

    if (temp != korzen) {
        korzen->klucz = temp->klucz;
        if (rodzic && rodzic->prawy == temp) {
            free(rodzic->prawy);  
            rodzic->prawy = NULL;
        } else if (rodzic && rodzic->lewy == temp) {
            free(rodzic->lewy);  
            rodzic->lewy = NULL;
        }
    } else {
        free(korzen);  
        korzen = NULL;
    }

    przywrocKopiec(korzen);
}

// Wczytywanie danych z pliku (we.txt)
void wczytajPlik(Wezel*& korzen) {
    string filename = "we.txt";  
    ifstream file(filename.c_str());
    if (!file) {
        cout << "Nie mozna otworzyc pliku\n";
        return;
    }

    int wartosc;
    while (file >> wartosc) {
        dodaj(korzen, wartosc);
    }

    file.close();
    cout << "Dane zostaly wczytane z pliku " << filename << ".\n";
}

// Wyswietlanie drzewa
void rysujDrzewo(string sp, string sn, Wezel* korzen) {
    if (korzen == NULL) return;

    string temp;
    string cr = "  ";
    string cl = "  ";
    string cp = "  ";
    cr[0] = 218; cr[1] = 196;
    cl[0] = 192; cl[1] = 196;
    cp[0] = 179;

    temp = sp;
    if (sn == cr) {
        temp[temp.length() - 2] = ' ';
    }

    rysujDrzewo(temp + cp, cr, korzen->prawy);

    temp = temp.substr(0, sp.length() - 2);
    cout << temp << sn << korzen->klucz << endl;

    temp = sp;
    if (sn == cl) {
        temp[temp.length() - 2] = ' ';
    }

    rysujDrzewo(temp + cp, cl, korzen->lewy);
}

// VLR
void VLR(Wezel* korzen) {
    if (korzen == NULL) return;
    cout << korzen->klucz << " ";
    VLR(korzen->lewy);
    VLR(korzen->prawy);
}

// LVR
void LVR(Wezel* korzen) {
    if (korzen == NULL) return;
    LVR(korzen->lewy);
    cout << korzen->klucz << " ";
    LVR(korzen->prawy);
}

// LRV
void LRV(Wezel* korzen) {
    if (korzen == NULL) return;
    LRV(korzen->lewy);
    LRV(korzen->prawy);
    cout << korzen->klucz << " ";
}

// Glowna funkcja
int main() {
    Wezel* korzen = NULL;
    int wybor;

    do {
        cout << "\nMenu:\n";
        cout << "1. Dodaj wezel\n";
        cout << "2. Usun maksymalny wezel\n";
        cout << "3. Wczytaj dane z pliku\n";
        cout << "4. Wyswietl drzewo\n";
        cout << "5. Wypisz VLR,LVR i LRV\n";
        cout << "6. Usun cale drzewo\n";
        cout << "0. Wyjscie\n";
        cout << "Twoj wybor: ";
        cin >> wybor;

        switch (wybor) {
            case 1: {
                int wartosc;
                cout << "Podaj wartosc do dodania: ";
                cin >> wartosc;
                dodaj(korzen, wartosc);
                break;
            }
            case 2:
                usunMaks(korzen);
                break;
            case 3: 
                wczytajPlik(korzen);  // Zmiana: usunieto pytanie o nazwe pliku
                break;
            case 4:
                rysujDrzewo("", "", korzen);
                break;
            case 5:
                cout << "VLR: ";
                VLR(korzen);
                cout << endl;
                cout << "LVR: ";
                LVR(korzen);
                cout << endl;
                cout << "LRV: ";
                LRV(korzen);
                cout << endl;
                break;
            case 6:
                usunCale(korzen);
                korzen = NULL;
                cout << "Drzewo zostalo usuniete\n";
                break;
            case 0:
                cout << "Koniec programu\n";
                break;
            default:
                cout << "Nieprawidlowy wybor\n";
        }
    } while (wybor != 0);

    usunCale(korzen);
    return 0;
}

