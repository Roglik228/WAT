///Godlevskyi Andrii
///Zadanie 1 z laboratoium 6


#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <cstdlib> 
using namespace std;

// Struktura wezla drzewa BST
struct Wezel {
    int dana;
    Wezel* lewy;
    Wezel* prawy;
};

// Tworzenie nowego wezla
Wezel* stworzWezel(int dana) {
    Wezel* nowyWezel = (Wezel*)malloc(sizeof(Wezel)); 
    if (nowyWezel == NULL) {
        cerr << "Blad alokacji pamieci!" << endl;
        exit(EXIT_FAILURE);
    }
    nowyWezel->dana = dana;
    nowyWezel->lewy = NULL;
    nowyWezel->prawy = NULL;
    return nowyWezel;
}

// Dodawanie wezla do drzewa
Wezel* dodaj(Wezel* korzen, int dana) {
    if (korzen == NULL) {
        return stworzWezel(dana);
    }
    if (dana < korzen->dana) {
        korzen->lewy = dodaj(korzen->lewy, dana);
    } else if (dana > korzen->dana) {
        korzen->prawy = dodaj(korzen->prawy, dana);
    }
    return korzen;
}

// Wyszukiwanie wezla w drzewie
Wezel* znajdz(Wezel* korzen, int dana) {
    if (korzen == NULL || korzen->dana == dana) {
        return korzen;
    }
    if (dana < korzen->dana) {
        return znajdz(korzen->lewy, dana);
    }
    return znajdz(korzen->prawy, dana);
}

// Znalezienie najmniejszego wezla w drzewie
Wezel* znajdzMin(Wezel* korzen) {
    while (korzen != NULL && korzen->lewy != NULL) {
        korzen = korzen->lewy;
    }
    return korzen;
}

// Usuwanie wezla z drzewa
Wezel* usun(Wezel* korzen, int dana) {
    if (korzen == NULL) return korzen;

    if (dana < korzen->dana) {
        korzen->lewy = usun(korzen->lewy, dana);
    } else if (dana > korzen->dana) {
        korzen->prawy = usun(korzen->prawy, dana);
    } else {
        // Wezel bez dzieci lub z jednym dzieckiem
        if (korzen->lewy == NULL) {
            Wezel* temp = korzen->prawy;
            free(korzen); // zwalnianie pamieci
            return temp;
        } else if (korzen->prawy == NULL) {
            Wezel* temp = korzen->lewy;
            free(korzen); // zwalnianie pamieci
            return temp;
        }

        // Wezel z dwoma dziecmi
        Wezel* temp = znajdzMin(korzen->prawy);
        korzen->dana = temp->dana;
        korzen->prawy = usun(korzen->prawy, temp->dana);
    }
    return korzen;
}

// Usuwanie calego drzewa
void usunCaleDrzewo(Wezel* korzen) {
    if (korzen == NULL) return;
    usunCaleDrzewo(korzen->lewy);   // Usuwamy lewe poddrzewo
    usunCaleDrzewo(korzen->prawy);  // Usuwamy prawe poddrzewo
    free(korzen); // Zwolnienie pamieci dla bie��cego wezla
}

// Funkcja do rysowania drzewa
void narysuj(string sp, string sn, Wezel* korzen) {
    string temp;
    string cr = "  "; // Dla prawego dziecka
    string cl = "  "; // Dla lewego dziecka
    string cp = "  "; // Pionowa linia
    cr[0] = 218; cr[1] = 196;
    cl[0] = 192; cl[1] = 196;
    cp[0] = 179;

    if (korzen) {
        temp = sp;
        if (sn == cr) {
            temp[temp.length() - 2] = ' ';
        }

        narysuj(temp + cp, cr, korzen->prawy);

        temp = temp.substr(0, sp.length() - 2);
        cout << temp << sn << korzen->dana << endl;

        temp = sp;
        if (sn == cl) {
            temp[temp.length() - 2] = ' ';
        }

        narysuj(temp + cp, cl, korzen->lewy);
    }
}

//VLR
void VLR(Wezel* korzen) {
    if (korzen != NULL) {
        cout << korzen->dana << " ";
        VLR(korzen->lewy);
        VLR(korzen->prawy);
    }
}

//LVR
void LVR(Wezel* korzen) {
    if (korzen != NULL) {
        LVR(korzen->lewy);
        cout << korzen->dana << " ";
        LVR(korzen->prawy);
    }
}

//LRV
void LRV(Wezel* korzen) {
    if (korzen != NULL) {
        LRV(korzen->lewy);
        LRV(korzen->prawy);
        cout << korzen->dana << " ";
    }
}

// Wczytywanie danych z pliku
Wezel* odczytajPlik(Wezel* korzen) {
    const string fileName = "we.txt";
    ifstream file(fileName.c_str());

    int wartosc;
    while (file >> wartosc) {
        korzen = dodaj(korzen, wartosc);
    }

    file.close();
    cout << "Dane wczytane z pliku: " << fileName << endl;
    return korzen;
}

// Glowna funkcja programu
int main() {
    Wezel* korzen = NULL;
    int wybor, wartosc;

    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Dodaj wezel\n";
        cout << "2. Usun wezel\n";
        cout << "3. Szukaj wezla\n";
        cout << "4. Wyswietl w porzadku VLR,LVR i LRV\n";
        cout << "5. Wyswietl drzewo\n";
        cout << "6. Wczytaj dane z pliku\n";
        cout << "7. Usun cale drzewo\n"; // Nowa opcja w menu
        cout << "0. Wyjscie\n";
        cout << "Wybierz opcje: ";
        cin >> wybor;

        switch (wybor) {
            case 1:
                cout << "Podaj wartosc do dodania: ";
                cin >> wartosc;
                korzen = dodaj(korzen, wartosc);
                break;
            case 2:
                cout << "Podaj wartosc do usuniecia: ";
                cin >> wartosc;
                korzen = usun(korzen, wartosc);
                break;
            case 3:
                cout << "Podaj wartosc do wyszukania: ";
                cin >> wartosc;
                if (znajdz(korzen, wartosc)) {
                    cout << "Wezel " << wartosc << " znaleziony\n";
                } else {
                    cout << "Wezel " << wartosc << " nie istnieje\n";
                }
                break;
            case 4:
                cout << "VLR: ";
                VLR(korzen);
                cout << endl;
                cout << "LVR: ";
                LVR(korzen);
                cout << endl;
                cout << "LRV: ";
                LRV(korzen);
                cout << endl;
                break;
            case 5:
                cout << "Drzewo BST:\n";
                narysuj("", "", korzen);
                break;
            case 6:
                korzen = odczytajPlik(korzen);
                break;
            case 7:
                usunCaleDrzewo(korzen);  // Usuwanie calego drzewa
                korzen = NULL;
                cout << "Drzewo zostalo usuniete\n";
                break;
            case 0:
                cout << "Koniec programu.\n";
                usunCaleDrzewo(korzen);  // Usuwamy drzewo przed zakonczeniem
                return 0;
            default:
                cout << "Nieprawidlowa opcja.\n";
        }
    }

    return 0;
}

