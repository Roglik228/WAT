///Godlevskyi Andrii
///Zadanie 2 z laboratoium 7


#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib> 
#include <sstream> 

using namespace std;

// Struktura wezla drzewa RB
struct Wezel {
    int dana;
    Wezel* lewy;
    Wezel* prawy;
    Wezel* rodzic;
    char kolor; // 'R' - czerwony, 'B' - czarny
};

// Funkcja do tworzenia wezla 
Wezel* utworz(Wezel* rodzic, int dana, char kolor) {
    Wezel* nowyWezel = (Wezel*)malloc(sizeof(Wezel));
    if (!nowyWezel) {
        cerr << "Blad alokacji pamieci" << endl;
        exit(1);
    }
    nowyWezel->dana = dana;
    nowyWezel->lewy = NULL;
    nowyWezel->prawy = NULL;
    nowyWezel->rodzic = rodzic;
    nowyWezel->kolor = kolor;
    return nowyWezel;
}

// Lewy obrot
void lewyObrot(Wezel*& korzen, Wezel* x) {
    Wezel* y = x->prawy;
    x->prawy = y->lewy;
    if (y->lewy != NULL) {
        y->lewy->rodzic = x;
    }
    y->rodzic = x->rodzic;
    if (x->rodzic == NULL) {
        korzen = y;
    } else if (x == x->rodzic->lewy) {
        x->rodzic->lewy = y;
    } else {
        x->rodzic->prawy = y;
    }
    y->lewy = x;
    x->rodzic = y;
}

// Prawy obrot
void prawyObrot(Wezel*& korzen, Wezel* y) {
    Wezel* x = y->lewy;
    y->lewy = x->prawy;
    if (x->prawy != NULL) {
        x->prawy->rodzic = y;
    }
    x->rodzic = y->rodzic;
    if (y->rodzic == NULL) {
        korzen = x;
    } else if (y == y->rodzic->prawy) {
        y->rodzic->prawy = x;
    } else {
        y->rodzic->lewy = x;
    }
    x->prawy = y;
    y->rodzic = x;
}

// Balansowanie po dodaniu
void balansuj(Wezel*& korzen, Wezel* nowy) {
    while (nowy != korzen && nowy->rodzic->kolor == 'R') {
        if (nowy->rodzic == nowy->rodzic->rodzic->lewy) {
            Wezel* wujek = nowy->rodzic->rodzic->prawy;
            if (wujek != NULL && wujek->kolor == 'R') {
                nowy->rodzic->kolor = 'B';
                wujek->kolor = 'B';
                nowy->rodzic->rodzic->kolor = 'R';
                nowy = nowy->rodzic->rodzic;
            } else {
                if (nowy == nowy->rodzic->prawy) {
                    nowy = nowy->rodzic;
                    lewyObrot(korzen, nowy);
                }
                nowy->rodzic->kolor = 'B';
                nowy->rodzic->rodzic->kolor = 'R';
                prawyObrot(korzen, nowy->rodzic->rodzic);
            }
        } else {
            Wezel* wujek = nowy->rodzic->rodzic->lewy;
            if (wujek != NULL && wujek->kolor == 'R') {
                nowy->rodzic->kolor = 'B';
                wujek->kolor = 'B';
                nowy->rodzic->rodzic->kolor = 'R';
                nowy = nowy->rodzic->rodzic;
            } else {
                if (nowy == nowy->rodzic->lewy) {
                    nowy = nowy->rodzic;
                    prawyObrot(korzen, nowy);
                }
                nowy->rodzic->kolor = 'B';
                nowy->rodzic->rodzic->kolor = 'R';
                lewyObrot(korzen, nowy->rodzic->rodzic);
            }
        }
    }
    korzen->kolor = 'B';
}

// Dodawanie nowego wezla
void dodaj(Wezel*& korzen, int dana) {
    Wezel* nowy = utworz(NULL, dana, 'R');
    Wezel* y = NULL;
    Wezel* x = korzen;

    while (x != NULL) {
        y = x;
        if (nowy->dana < x->dana)
            x = x->lewy;
        else
            x = x->prawy;
    }

    nowy->rodzic = y;
    if (y == NULL) {
        korzen = nowy;
    } else if (nowy->dana < y->dana) {
        y->lewy = nowy;
    } else {
        y->prawy = nowy;
    }

    balansuj(korzen, nowy);
}

// Funkcja do znalezienia najmniejszego wezla w poddrzewie
Wezel* minWez(Wezel* korzen) {
    while (korzen && korzen->lewy != NULL)
        korzen = korzen->lewy;
    return korzen;
}

// Funkcja do usuwania wezla
Wezel* usun(Wezel* korzen, int dana) {
    if (korzen == NULL)
        return korzen;

    if (dana < korzen->dana)
        korzen->lewy = usun(korzen->lewy, dana);
    else if (dana > korzen->dana)
        korzen->prawy = usun(korzen->prawy, dana);
    else {
        if ((korzen->lewy == NULL) || (korzen->prawy == NULL)) {
            Wezel* temp = korzen->lewy ? korzen->lewy : korzen->prawy;
            if (temp == NULL) {
                temp = korzen;
                korzen = NULL;
            } else
                *korzen = *temp;
            free(temp);
        } else {
            Wezel* temp = minWez(korzen->prawy);
            korzen->dana = temp->dana;
            korzen->prawy = usun(korzen->prawy, temp->dana);
        }
    }

    return korzen;
}

// Funkcja do zamiany liczby na string
string intToString(int liczba) {
    stringstream ss;
    ss << liczba;
    return ss.str();
}

// Funkcja do wyszukiwania wezla 
bool znajdzWezelZeSciezka(Wezel* korzen, int dana, string sciezka = "") {
    if (korzen == NULL) {
        cout << "Wartosc " << dana << " nie zostala znaleziona." << endl;
        return false;
    }

    sciezka += intToString(korzen->dana) + "->";

    if (dana == korzen->dana) {
        sciezka = sciezka.substr(0, sciezka.length() - 2);
        cout << "Wartosc " << dana << " zostala znaleziona, sciezka do niej: " << sciezka << endl;
        return true;
    }

    if (dana < korzen->dana)
        return znajdzWezelZeSciezka(korzen->lewy, dana, sciezka);
    return znajdzWezelZeSciezka(korzen->prawy, dana, sciezka);
}

// Funkcja do rysowania drzewa
void narysuj(string sp, string sn, Wezel* korzen) {
    string temp;
    string cr = "  ";
    string cl = "  ";
    string cp = "  ";
    cr[0] = 218; cr[1] = 196;
    cl[0] = 192; cl[1] = 196;
    cp[0] = 179;

    if (korzen) {
        temp = sp;
        if (sn == cr) {
            temp[temp.length() - 2] = ' ';
        }
        narysuj(temp + cp, cr, korzen->prawy);

        temp = temp.substr(0, sp.length() - 2);
        cout << temp << sn << korzen->kolor << ":" << korzen->dana << endl;

        temp = sp;
        if (sn == cl) {
            temp[temp.length() - 2] = ' ';
        }
        narysuj(temp + cp, cl, korzen->lewy);
    }
}

//VLR
void VLR(Wezel* korzen) {
    if (korzen) {
        cout << korzen->dana << " ";
        VLR(korzen->lewy);
        VLR(korzen->prawy);
    }
}

//LVR
void LVR(Wezel* korzen) {
    if (korzen) {
        LVR(korzen->lewy);
        cout << korzen->dana << " ";
        LVR(korzen->prawy);
    }
}

//LRV
void LRV(Wezel* korzen) {
    if (korzen) {
        LRV(korzen->lewy);
        LRV(korzen->prawy);
        cout << korzen->dana << " ";
    }
}

// Wczytywanie danych z pliku
void wczytaj(Wezel*& korzen) {
    ifstream plik("we.txt");
    if (!plik.is_open()) {
        cerr << "Nie mozna otworzyc pliku we.txt" << endl;
        return;
    }

    int liczba;
    while (plik >> liczba) {
        dodaj(korzen, liczba);
    }
    cout<<"Dane sa wczytane z pliku we.txt"<<endl;

    plik.close();
}

// Usuwanie drzewa
void usunDrzewo(Wezel*& korzen) {
    if (korzen) {
        usunDrzewo(korzen->lewy);
        usunDrzewo(korzen->prawy);
        free(korzen);
        korzen = NULL;
    }
}

int main() {
    Wezel* korzen = NULL;
    int wybor;

    do {
        cout << "\nMenu:\n";
        cout << "1. Dodaj wezel\n";
        cout << "2. Usun wezel\n";
        cout << "3. Wyswietl w porzadku VLR, LVR i LRV\n";
        cout << "4. Narysuj drzewo\n";
        cout << "5. Wczytaj dane z pliku\n";
        cout << "6. Wyszukaj wezel\n";
        cout << "7. Usun cale drzewo\n";
        cout << "0. Wyjdz\n";
        cout << "Twoj wybor: ";
        cin >> wybor;

        switch (wybor) {
            case 1: {
                int dana;
                cout << "Podaj wartosc do dodania: ";
                cin >> dana;
                dodaj(korzen, dana);
                cout << "Wartosc "<<dana<<" zostala dodana"<<endl;
                break;
            }
            case 2: {
                int dana;
                cout << "Podaj wartosc do usuniecia: ";
                cin >> dana;
                korzen = usun(korzen, dana);
                cout << "Wartosc "<<dana<<" zostala usunieta"<<endl;
                break;
            }
            case 3:
                cout << "VLR: ";
                VLR(korzen);
                cout << "\nLVR: ";
                LVR(korzen);
                cout << "\nLRV: ";
                LRV(korzen);
                cout << endl;
                break;
            case 4:
                narysuj("", "", korzen);
                break;
            case 5:
                wczytaj(korzen);
                break;
            case 6: {
                int dana;
                cout << "Podaj wartosc do wyszukania: ";
                cin >> dana;
                znajdzWezelZeSciezka(korzen, dana);
                break;
            }
            case 7:
                usunDrzewo(korzen);
                cout << "Drzewo zostalo usuniete\n";
                break;
            case 0:
                cout << "Koniec programu\n";
                break;
            default:
                cout << "Nieprawidlowy wybor,sprobuj ponownie\n";
        }
    } while (wybor != 0);

    return 0;
}
