///Godlevskyi Andrii
///Zadanie 1 z laboratoium 7


#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <sstream> 

using namespace std;

// Struktura wezla drzewa AVL
struct Wezel {
    int dana;
    Wezel* lewy;
    Wezel* prawy;
    int wysokosc;
};

// Funkcja do obliczenia wysokosci wezla
int wysokosc(Wezel* w) {
    return (w == NULL) ? 0 : w->wysokosc;
}

// Funkcja do obliczenia balansu wezla
int balans(Wezel* w) {
    return (w == NULL) ? 0 : wysokosc(w->lewy) - wysokosc(w->prawy);
}

// Rotacja w prawo
Wezel* rotacjaPrawo(Wezel* y) {
    Wezel* x = y->lewy;
    Wezel* T = x->prawy;

    x->prawy = y;
    y->lewy = T;

    y->wysokosc = max(wysokosc(y->lewy), wysokosc(y->prawy)) + 1;
    x->wysokosc = max(wysokosc(x->lewy), wysokosc(x->prawy)) + 1;

    return x;
}

// Rotacja w lewo
Wezel* rotacjaLewo(Wezel* x) {
    Wezel* y = x->prawy;
    Wezel* T = y->lewy;

    y->lewy = x;
    x->prawy = T;

    x->wysokosc = max(wysokosc(x->lewy), wysokosc(x->prawy)) + 1;
    y->wysokosc = max(wysokosc(y->lewy), wysokosc(y->prawy)) + 1;

    return y;
}

// Funkcja do dodawania wezla
Wezel* dodaj(Wezel* korzen, int dana) {
    if (korzen == NULL) {
        Wezel* nowy = (Wezel*)malloc(sizeof(Wezel));
        nowy->dana = dana;
        nowy->lewy = nowy->prawy = NULL;
        nowy->wysokosc = 1;
        return nowy;
    }

    if (dana < korzen->dana)
        korzen->lewy = dodaj(korzen->lewy, dana);
    else if (dana > korzen->dana)
        korzen->prawy = dodaj(korzen->prawy, dana);
    else
        return korzen; // Brak duplikatow

    korzen->wysokosc = 1 + max(wysokosc(korzen->lewy), wysokosc(korzen->prawy));

    int bal = balans(korzen);

    // Rotacje w zaleznosci od balansu
    if (bal > 1 && dana < korzen->lewy->dana)
        return rotacjaPrawo(korzen);

    if (bal < -1 && dana > korzen->prawy->dana)
        return rotacjaLewo(korzen);

    if (bal > 1 && dana > korzen->lewy->dana) {
        korzen->lewy = rotacjaLewo(korzen->lewy);
        return rotacjaPrawo(korzen);
    }

    if (bal < -1 && dana < korzen->prawy->dana) {
        korzen->prawy = rotacjaPrawo(korzen->prawy);
        return rotacjaLewo(korzen);
    }

    return korzen;
}

// Funkcja minimalnego wezla
Wezel* minWez(Wezel* korzen) {
    while (korzen->lewy != NULL)
        korzen = korzen->lewy;
    return korzen;
}

// Funkcja do usuwania wezla
Wezel* usun(Wezel* korzen, int dana) {
    if (korzen == NULL)
        return korzen;

    if (dana < korzen->dana)
        korzen->lewy = usun(korzen->lewy, dana);
    else if (dana > korzen->dana)
        korzen->prawy = usun(korzen->prawy, dana);
    else {
        if ((korzen->lewy == NULL) || (korzen->prawy == NULL)) {
            Wezel* temp = korzen->lewy ? korzen->lewy : korzen->prawy;
            if (temp == NULL) {
                temp = korzen;
                korzen = NULL;
            } else
                *korzen = *temp;
            free(temp);
        } else {
            Wezel* temp = minWez(korzen->prawy);
            korzen->dana = temp->dana;
            korzen->prawy = usun(korzen->prawy, temp->dana);
        }
    }

    if (korzen == NULL)
        return korzen;

    korzen->wysokosc = 1 + max(wysokosc(korzen->lewy), wysokosc(korzen->prawy));

    int bal = balans(korzen);

    if (bal > 1 && balans(korzen->lewy) >= 0)
        return rotacjaPrawo(korzen);

    if (bal > 1 && balans(korzen->lewy) < 0) {
        korzen->lewy = rotacjaLewo(korzen->lewy);
        return rotacjaPrawo(korzen);
    }

    if (bal < -1 && balans(korzen->prawy) <= 0)
        return rotacjaLewo(korzen);

    if (bal < -1 && balans(korzen->prawy) > 0) {
        korzen->prawy = rotacjaPrawo(korzen->prawy);
        return rotacjaLewo(korzen);
    }

    return korzen;
}

//LVR
void LVR(Wezel* korzen) {
    if (korzen != NULL) {
        LVR(korzen->lewy);
        cout << korzen->dana << " ";
        LVR(korzen->prawy);
    }
}

//VLR
void VLR(Wezel* korzen) {
    if (korzen != NULL) {
        cout << korzen->dana << " ";
        VLR(korzen->lewy);
        VLR(korzen->prawy);
    }
}

//LRV
void LRV(Wezel* korzen) {
    if (korzen != NULL) {
        LRV(korzen->lewy);
        LRV(korzen->prawy);
        cout << korzen->dana << " ";
    }
}

// Funkcja do usuwania calego drzewa
void usunCaleDrzewo(Wezel*& korzen) {
    if (korzen != NULL) {
        usunCaleDrzewo(korzen->lewy);
        usunCaleDrzewo(korzen->prawy);
        free(korzen);
        korzen = NULL;
    }
}

// Funkcja do zamiany liczby na string
string intToString(int liczba) {
    stringstream ss;
    ss << liczba;
    return ss.str();
}

// Funkcja do wyszukiwania wezla
bool znajdzWezelZeSciezka(Wezel* korzen, int dana, string sciezka = "") {
    if (korzen == NULL) {
        cout << "Wartosc " << dana << " nie zostala znaleziona." << endl;
        return false;
    }

    // Dodanie aktualnego wezla do sciezki
    sciezka += intToString(korzen->dana) + "->";

    if (dana == korzen->dana) {
        // Usuniecie ostatniego "->" i wyswietlenie sciezki
        sciezka = sciezka.substr(0, sciezka.length() - 2);
        cout << "Wartosc " << dana << " zostala znaleziona, sciezka do niej: " << sciezka << endl;
        return true;
    }

    if (dana < korzen->dana)
        return znajdzWezelZeSciezka(korzen->lewy, dana, sciezka);
    return znajdzWezelZeSciezka(korzen->prawy, dana, sciezka);
}

// Funkcja do rysowania drzewa
void narysuj(string sp, string sn, Wezel* korzen) {
    string temp;
    string cr = "  ";
    string cl = "  ";
    string cp = "  ";
    cr[0] = 218; cr[1] = 196;
    cl[0] = 192; cl[1] = 196;
    cp[0] = 179;

    if (korzen) {
        temp = sp;
        if (sn == cr) {
            temp[temp.length() - 2] = ' ';
        }

        narysuj(temp + cp, cr, korzen->prawy);

        temp = temp.substr(0, sp.length() - 2);
        cout << temp << sn << korzen->dana << ":" << balans(korzen) << endl;

        temp = sp;
        if (sn == cl) {
            temp[temp.length() - 2] = ' ';
        }

        narysuj(temp + cp, cl, korzen->lewy);
    }
}

// Funkcja glowna
int main() {
    Wezel* korzen = NULL;
    int wybor, dana;
    string nazwaPliku = "we.txt";

    do {
        cout << "\nMenu:\n";
        cout << "1. Dodaj wezel\n";
        cout << "2. Usun wezel\n";
        cout << "3. Wyswietl w porzadku VLR,LVR i LRV\n";
        cout << "4. Narysuj drzewo\n";
        cout << "5. Wczytaj dane z pliku\n";
        cout << "6. Wyszukaj wezel\n";
        cout << "7. Usun cale drzewo\n";
        cout << "0. Wyjdz\n";
        cout << "Twoj wybor: ";
        cin >> wybor;

        switch (wybor) {
            case 1:
                cout << "Podaj wartosc do dodania: ";
                cin >> dana;
                korzen = dodaj(korzen, dana);
                cout << "Wartosc "<<dana<<" zostala dodana"<<endl;
                break;
            case 2:
                cout << "Podaj wartosc do usuniecia: ";
                cin >> dana;
                korzen = usun(korzen, dana);
                cout << "Wartosc "<<dana<<" zostala usunieta"<<endl;
                break;
            case 3:
                cout << "VLR: ";
                VLR(korzen);
                cout << endl;
                cout << "LVR: ";
                LVR(korzen);
                cout << endl;
                cout << "LRV: ";
                LRV(korzen);
                cout << endl;
                break;
            case 4:
                cout << "Rysunek drzewa:\n";
                narysuj("", "", korzen);
                break;
            case 5: {
                ifstream plik(nazwaPliku.c_str());
                if (plik.is_open()) {
                    while (plik >> dana) {
                        korzen = dodaj(korzen, dana);
                    }
                    plik.close();
                    cout << "Dane zostaly wczytane z pliku we.txt" << endl;
                } else {
                    cout << "Nie mozna otworzyc pliku" << endl;
                }
                break;
            }
           case 6:
                cout << "Podaj wartosc do wyszukania: ";
                cin >> dana;
                znajdzWezelZeSciezka(korzen, dana);
                break;

            case 7:
                usunCaleDrzewo(korzen);
                cout << "Drzewo zostalo usuniete" << endl;
                break;
            case 0:
                cout << "Koniec programu.\n";
                usunCaleDrzewo(korzen);  // Usuwamy drzewo przed zakonczeniem
                return 0;
            default:
                cout << "Nieprawidlowy wybor,sprobuj ponownie" << endl;
        }
    } while (wybor != 0);

    return 0;
}

