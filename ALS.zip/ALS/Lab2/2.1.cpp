////Godlevskyi Andrii KY1S1

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

// Funkcja dodajaca element na koncu listy
void append(struct Node** head, int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = NULL;

    if (*head == NULL) {
        *head = newNode;
    } else {
        struct Node* temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

// Funkcja wyswietlajaca elementy listy (po 10 elementow w wierszu)
void displayList(struct Node* head) {
    struct Node* temp = head;
    int count = 0;

    while (temp != NULL) {
        printf("%4d ", temp->data); // Wyrownanie do prawej 
        count++;

        if (count % 10 == 0) {
            printf("\n"); // Nowa linia po 10 elementach
        }

        temp = temp->next;
    }
    if (count % 10 != 0) {
        printf("\n"); 
    }
}

// Funkcja obliczajaca srednia wartosci w liscie
double calculateAverage(struct Node* head) {
    int sum = 0, count = 0;
    struct Node* temp = head;
    while (temp != NULL) {
        sum += temp->data;
        count++;
        temp = temp->next;
    }
    return (count > 0) ? (double)sum / count : 0.0;
}

// Funkcja usuwajaca wartosci nieparzyste z listy
void removeOdd(struct Node** head) {
    while (*head != NULL && (*head)->data % 2 != 0) {
        struct Node* temp = *head;
        *head = (*head)->next;
        free(temp);
    }

    struct Node* current = *head;
    while (current != NULL && current->next != NULL) {
        if (current->next->data % 2 != 0) {
            struct Node* temp = current->next;
            current->next = current->next->next;
            free(temp);
        } else {
            current = current->next;
        }
    }
}

// Funkcja czyszczaca pamiec zajeta przez liste
void clearList(struct Node** head) {
    while (*head != NULL) {
        struct Node* temp = *head;
        *head = (*head)->next;
        free(temp);
    }
}

// Funkcja wyswietlajaca menu i obslugujaca wybor uzytkownika
void menu() {
    printf("\n--- MENU ---\n");
    printf("1. Wyswietl zawartosc listy\n");
    printf("2. Oblicz srednia wartosci w liscie\n");
    printf("3. Usun wartosci nieparzyste\n");
    printf("4. Wyjscie\n");
    printf("Wybierz opcje: ");
}

int main() {
    struct Node* head = NULL;
    int choice;
    double avg;

    // Wypelnienie listy wartosciami od 1 do 100
    for (int i = 1; i <= 100; i++) {
        append(&head, i);
    }

    while (1) {
        menu();
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Zawartosc listy:\n");
                displayList(head);
                break;

            case 2:
                avg = calculateAverage(head);
                printf("Srednia wartosc: %.2f\n", avg);
                break;

            case 3:
                removeOdd(&head);
                printf("Nieparzyste wartosci usuniete z listy.\n");
                break;

            case 4:
                printf("Koniec programu.\n");
                clearList(&head);
                return 0;

            default:
                printf("Nieprawidlowy wybor. Sprobuj ponownie.\n");
        }
    }
}

