////Godlevskyi Andrii KY1S1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Node {
    char imie[50];
    char nazwisko[50];
    char telefon[15];
    struct Node* next;
    struct Node* prev;
} Node;

Node* head = NULL;
Node* tail = NULL;

// Funkcja tworzaca nowy wezel
Node* utworzNode(char* imie, char* nazwisko, char* telefon) {
    Node* nowyNode = (Node*)malloc(sizeof(Node));
    strcpy(nowyNode->imie, imie);
    strcpy(nowyNode->nazwisko, nazwisko);
    strcpy(nowyNode->telefon, telefon);
    nowyNode->next = nowyNode->prev = NULL;
    return nowyNode;
}

// Funkcja czyszczaca bufor wejscia
void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) { }
}

// Funkcja dodajaca nowa wizytowke
void addwiz(char* imie, char* nazwisko, char* telefon) {
    Node* nowyNode = utworzNode(imie, nazwisko, telefon);
    if (head == NULL) {
        head = tail = nowyNode;
    } else {
        tail->next = nowyNode;
        nowyNode->prev = tail;
        tail = nowyNode;
    }
    printf("Wizytowka dodana pomyslnie.\n");
}

// Funkcja wyszukujaca wizytowke
void findwiz(char* nazwisko) {
    Node* temp = head;
    while (temp != NULL) {
        if (strcmp(temp->nazwisko, nazwisko) == 0) {
            printf("Znaleziono: Imie: %s , Nazwisko: %s, Telefon: %s\n", temp->imie, temp->nazwisko, temp->telefon);
            return;
        }
        temp = temp->next;
    }
    printf("Nie znaleziono wizytowki dla nazwiska: %s\n", nazwisko);
}

// Funkcja wypisujaca wizytowki od A do Z
void showWizAZ() {
    Node* temp = head;
    if (temp == NULL) {
        printf("Brak wizytowek do wyswietlenia.\n");
        return;
    }
    while (temp != NULL) {
        printf("\nImie: %s , Nazwisko: %s, Telefon: %s", temp->imie, temp->nazwisko, temp->telefon);
        temp = temp->next;
    }
}

// Funkcja wypisujaca wizytowki od Z do A
void showWizZA() {
    Node* temp = tail;
    if (temp == NULL) {
        printf("Brak wizytowek do wyswietlenia.\n");
        return;
    }
    while (temp != NULL) {
        printf("\nImie: %s , Nazwisko: %s, Telefon: %s", temp->imie, temp->nazwisko, temp->telefon);
        temp = temp->prev;
    }
}

// Funkcja usuwajaca wizytowke
void delwiz(char* nazwisko) {
    Node* temp = head;
    while (temp != NULL) {
        if (strcmp(temp->nazwisko, nazwisko) == 0) {
            if (temp->prev != NULL) temp->prev->next = temp->next;
            else head = temp->next;

            if (temp->next != NULL) temp->next->prev = temp->prev;
            else tail = temp->prev;

            free(temp);
            printf("Wizytowka usunieta pomyslnie.\n");
            return;
        }
        temp = temp->next;
    }
    printf("Nie znaleziono wizytowki dla nazwiska: %s\n", nazwisko);
}

// Funkcja zapisujaca rekordy do pliku
void zapiszplik() {
    FILE* plik = fopen("wizytowki.txt", "w");
    if (plik == NULL) {
        printf("Blad przy otwieraniu pliku.\n");
        return;
    }
    Node* temp = head;
    while (temp != NULL) {
        fprintf(plik, "%s %s %s\n", temp->imie, temp->nazwisko, temp->telefon);
        temp = temp->next;
    }
    fclose(plik);
    printf("Rekordy zapisane pomyslnie do pliku wizytowki.txt.\n");
}

// Funkcja wyswietlajaca menu
void wyswietlMenu() {
    printf("\n |||||||||||||MENU||||||||||||| ");
    printf("\nd - Dodaj wizytowke\n");
    printf("s - Szukaj wizytowki\n");
    printf("w - Wypisz wizytowki (A...Z)\n");
    printf("v - Wypisz wizytowki (Z...A)\n");
    printf("u - Usun wizytowke\n");
    printf("z - Zapisz rekordy do pliku\n");
    printf("Ctrl-C - Zakoncz dzialanie programu\n");
}

int main() {
    char wybor;
    char imie[50], nazwisko[50], telefon[15];

    wyswietlMenu();

    while (1) {

        printf("\n \n Wybierz opcje: ");
        wybor = getchar();

        clearInputBuffer(); // wyczysc bufor po wprowadzeniu opcji

        switch (wybor) {
            case 'd':
                printf("Podaj imie: ");
                scanf("%49s", imie);
                printf("Podaj nazwisko: ");
                scanf("%49s", nazwisko);
                printf("Podaj telefon: ");
                scanf("%14s", telefon);
                clearInputBuffer(); // wyczysc bufor po wprowadzeniu danych
                addwiz(imie, nazwisko, telefon);
                break;
            case 's':
                printf("Podaj nazwisko do wyszukania: ");
                scanf("%49s", nazwisko);
                clearInputBuffer();
                findwiz(nazwisko);
                break;
            case 'w':
                showWizAZ();
                break;
            case 'v':
                showWizZA();
                break;
            case 'u':
                printf("Podaj nazwisko do usuniecia: ");
                scanf("%49s", nazwisko);
                clearInputBuffer();
                delwiz(nazwisko);
                break;
            case 'z':
                zapiszplik();
                break;
            default:
                printf("Nieprawidlowa opcja, sprobuj ponownie.\n");
                break;
        }

        // Wyswietl menu po wykonaniu akcji
        wyswietlMenu();
    }

    return 0;
}

