///Godlevskyi Andrii KY1S1
#include <stdio.h>
#include <stdlib.h>

// Struktura pojedynczego elementu listy jednokierunkowej
struct Node {
    int value;
    struct Node *next;
};

// Funkcja do dodawania elementu do listy jednokierunkowej
void dodaj(struct Node **head, int value) {
    struct Node *new_node = (struct Node*)malloc(sizeof(struct Node));
    new_node->value = value;
    new_node->next = NULL;

    if (*head == NULL) {
        *head = new_node;
    } else {
        struct Node *temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = new_node;
    }
}

// Funkcja sito do usuwania z listy jednokierunkowej liczb nie pierwszych
void sito(struct Node **head, int n) {
    int *pierwsza = (int*)malloc((n + 1) * sizeof(int));
    for (int i = 0; i <= n; i++) {
        pierwsza[i] = 1;
    }

    // Sito Eratostenesa
    for (int p = 2; p * p <= n; p++) {
        if (pierwsza[p]) {
            for (int i = p * p; i <= n; i += p) {
                pierwsza[i] = 0;
            }
        }
    }

    // Wypelnianie listy tylko liczbami pierwszymi
    for (int i = 2; i <= n; i++) {
        if (pierwsza[i]) {
            dodaj(head, i);
        }
    }

    free(pierwsza);
}

// Funkcja do wyswietlania i zapisywania listy liczb pierwszych do pliku
void wypizap(struct Node *head, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Blad otwarcia pliku.\n");
        return;
    }

    struct Node *current = head;
    int counter = 0; // Licznik elementow w jednym wierszu

    while (current != NULL) {
        printf("%-4d ", current->value);    // Wyswietlanie na ekranie
        fprintf(file, "%-4d ", current->value); // Zapisywanie do pliku

        counter++;
        if (counter %10 == 0) { // Po 10 elementach wstaw nowa linie
            printf("\n");
            fprintf(file, "\n");
            counter = 0;
        }

        current = current->next;
    }

    // Dodanie nowej linii na koncu, jesli nie byla ostatnia
    if (counter != 0) {
        printf("\n");
        fprintf(file, "\n");
    }

    fclose(file);
}

// Funkcja glowna
int main() {
    int n;
    printf("Podaj gorny zakres n: ");
    scanf("%d", &n);

    if (n < 2) {
        printf("Brak liczb pierwszych w przedziale.\n");
        return 0;
    }
    
    printf("Liczby pierwsze z zakresu od 2 do %d \n",n);
    struct Node *head = NULL;
    sito(&head, n);
    wypizap(head, "Wy.txt");

    // Zwolnienie pamieci
    struct Node *temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp);
    }

    return 0;
}

