///Godlevskyi Andrii KY1S1
#include <stdio.h>
#include <stdlib.h>

// Struktura pojedynczego elementu listy jednokierunkowej
struct Node {
    int value;
    struct Node *next;
};

// Funkcja do dodawania elementu do listy jednokierunkowej
void dodaj(struct Node **head, int value) {
    struct Node *new_node = (struct Node*)malloc(sizeof(struct Node));
    new_node->value = value;
    new_node->next = NULL;

    if (*head == NULL) {
        *head = new_node;
    } else {
        struct Node *temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = new_node;
    }
}

// Funkcja do wyswietlania i zapisywania listy liczb pierwszych do pliku
void wypizap(struct Node *head, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Blad otwarcia pliku\n");
        return;
    }

    struct Node *current = head;
    int counter = 0; // Licznik elementow w jednym wierszu

    while (current != NULL) {
        printf("%-4d ", current->value);   // Wyswietlanie na ekranie
        fprintf(file, "%-4d ", current->value); // Zapisywanie do pliku

        counter++;
        if (counter %10 == 0) { // Po 10 elementach wstaw nowa linie
            printf("\n");
            fprintf(file, "\n");
            counter = 0;
        }

        current = current->next;
    }

    // Dodanie nowej linii na koncu, jesli nie byla ostatnia
    if (counter != 0) {
        printf("\n");
        fprintf(file, "\n");
    }

    fclose(file);
}

// Funkcja do inicjalizacji listy liczb pierwszych za pomoca Sita Atkina-Bernsteina
struct Node* atkin(int n) {
    if (n < 2) return NULL;

    int *sieve = (int*)malloc((n + 1) * sizeof(int));
    for (int i = 0; i <= n; i++) {
        sieve[i] = 0;
    }

    for (int x = 1; x * x <= n; x++) {
        for (int y = 1; y * y <= n; y++) {
            int num = (4 * x * x) + (y * y);
            if (num <= n && (num % 12 == 1 || num % 12 == 5)) {
                sieve[num] ^= 1;
            }
            num = (3 * x * x) + (y * y);
            if (num <= n && num % 12 == 7) {
                sieve[num] ^= 1;
            }
            num = (3 * x * x) - (y * y);
            if (x > y && num <= n && num % 12 == 11) {
                sieve[num] ^= 1;
            }
        }
    }

    for (int i = 5; i * i <= n; i++) {
        if (sieve[i]) {
            for (int j = i * i; j <= n; j += i * i) {
                sieve[j] = 0;
            }
        }
    }

    struct Node *head = NULL;
    if (n >= 2) dodaj(&head, 2);
    if (n >= 3) dodaj(&head, 3);
    for (int i = 5; i <= n; i++) {
        if (sieve[i]) {
            dodaj(&head, i);
        }
    }

    free(sieve);
    return head;
}

// Funkcja glowna
int main() {
    int n;
    printf("Podaj gorny zakres n: ");
    scanf("%d", &n);
    
    printf("Liczby pierwsze z zakresu od 2 do %d \n",n);
    struct Node *head = atkin(n);
    wypizap(head, "Wy.txt");

    // Zwolnienie pamieci
    struct Node *temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp);
    }

    return 0;
}

