//Godlevskyi Anrii KY1S1//
//Zadanie 2 z laboratorium 4//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Struktura stosu z wykorzystaniem wskaznikow
typedef struct Stos {
    char data;
    struct Stos *next;
} Stos;

// Funkcja tworzaca nowy wezel stosu
Stos* createNode(char data) {
    Stos* node = (Stos*)malloc(sizeof(Stos));
    node->data = data;
    node->next = NULL;
    return node;
}

// Funkcja sprawdzania czy stos jest pusty
int pusty(Stos* top) {
    return top == NULL;
}

// Funkcja dodania elementu na stos
void dod(Stos** top, char data) {
    Stos* node = createNode(data);
    node->next = *top;
    *top = node;
}

// Funkcja usuwania elementu ze stosu
char usun(Stos** top) {
    if (pusty(*top)) {
        return '\0';
    }
    Stos* temp = *top;
    char usuniety = temp->data;
    *top = (*top)->next;
    free(temp);
    return usuniety;
}

// Funkcja dodajaca duze liczby
void dodaj(char* num1, char* num2, char* wynik) {
    Stos *stack1 = NULL, *stack2 = NULL, *stackWynik = NULL;

    // Wstawiamy cyfry obu liczb na odpowiednie stosy
    for (int i = 0; num1[i] != '\0'; i++) {
        dod(&stack1, num1[i]);
    }
    for (int i = 0; num2[i] != '\0'; i++) {
        dod(&stack2, num2[i]);
    }

    int carry = 0; // Przeniesienie
    int index = 0;

    while (!pusty(stack1) || !pusty(stack2) || carry) {
        int digit1 = pusty(stack1) ? 0 : usun(&stack1) - '0';
        int digit2 = pusty(stack2) ? 0 : usun(&stack2) - '0';

        int sum = digit1 + digit2 + carry;
        carry = sum / 10; // Obliczanie przeniesienia
        dod(&stackWynik, (sum % 10) + '0'); // Wstawianie cyfry wyniku
    }

    // Zapis wyniku do tablicy
    while (!pusty(stackWynik)) {
        wynik[index++] = usun(&stackWynik);
    }
    wynik[index] = '\0'; // Zakonczenie ciagu znak�w
}

int main() {
    char num1[1000], num2[1000], wynik[2000];
    char wybor;

    printf("Czy chcesz wczytac dane z pliku? (t/n): ");
    scanf(" %c", &wybor);

    if (wybor == 't' || wybor == 'T') {
        FILE* we = fopen("we.txt", "r");
        if (we == NULL) {
            perror("Nie mozna otworzyc pliku we.txt");
            return 1;
        }

        if (fscanf(we, "%s %s", num1, num2) != 2) {
            perror("Blad podczas odczytu danych z pliku");
            fclose(we);
            return 1;
        }
        fclose(we);
    } else {
        printf("Podaj pierwsza liczbe: ");
        scanf("%s", num1);
        printf("Podaj druga liczbe: ");
        scanf("%s", num2);
    }

    // Dodawanie duzych liczb
    dodaj(num1, num2, wynik);

    printf("Wynik dodawania: %s\n", wynik);

    FILE* wy = fopen("wy.txt", "w");
    if (wy == NULL) {
        perror("Nie mozna otworzyc pliku wy.txt");
        return 1;
    }

    fprintf(wy, "Wynik dodawania: %s\n", wynik);
    fclose(wy);

    printf("Wynik zapisano do pliku wy.txt\n");

    return 0;
}

