//Godlevskyi Anrii KY1S1//
//Zadanie 1 z laboratorium 4//

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

// Struktura stosu z wykorzystaniem wskaznikow
typedef struct Stos {
    char data;
    struct Stos *next;
} Stos;

// Funkcja tworzaca nowy wezel stosu
Stos* createNode(char data) {
    Stos* node = (Stos*)malloc(sizeof(Stos));
    node->data = data;
    node->next = NULL;
    return node;
}

// Funkcja sprawdzania czy stos jest pusty
int pusty(Stos* top) {
    return top == NULL;
}

// Funkcja dodania elementu na stos
void dod(Stos** top, char data) {
    Stos* node = createNode(data);
    node->next = *top;
    *top = node;
}

// Funkcja usuwania elementu ze stosu
char usun(Stos** top) {
    if (pusty(*top)) {
        return '\0';
    }
    Stos* temp = *top;
    char usuniety = temp->data;
    *top = (*top)->next;
    free(temp);
    return usuniety;
}

// Funkcja zwracania elementu ze szczytu stosu
char top(Stos* top) {
    if (pusty(top)) {
        return '\0';
    }
    return top->data;
}

// Funkcja sprawdzania priorytetu
int prior(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/' || op == '%') return 2;
    return 0;
}

// Konwertacja infix na postfix
void inftopost(char* infix, char* postfix) {
    Stos* stack = NULL; // Stos operatorow
    int j = 0; // Indeks dla wyrazenia postfiksowego

    for (int i = 0; infix[i] != '\0';) {
        char element = infix[i];

        if (isalnum(element)) {
            while (isalnum(infix[i])) { // Obsluga liczb wielocyfrowych
                postfix[j++] = infix[i++];
            }
            postfix[j++] = ' '; // Separator miedzy liczbami
        } 
        else if (element == '(') {
            dod(&stack, element);
            i++;
        } 
        else if (element == ')') {
            while (!pusty(stack) && top(stack) != '(') {
                postfix[j++] = usun(&stack);
                postfix[j++] = ' '; // Separator miedzy operatorami
            }
            if (!pusty(stack) && top(stack) == '(') {
                usun(&stack); // Usuwamy '(' ze stosu
            }
            i++;
        } 
        else {
            while (!pusty(stack) && prior(top(stack)) >= prior(element)) {
                postfix[j++] = usun(&stack);
                postfix[j++] = ' '; // Separator miedzy operatorami
            }
            dod(&stack, element);
            i++;
        }
    }

    while (!pusty(stack)) {
        postfix[j++] = usun(&stack);
        postfix[j++] = ' '; // Separator miedzy operatorami
    }

    postfix[j] = '\0'; // Zakonczenie wyrazenia
}

int main() {
    char infix[1000];
    char postfix[1000];
    char wybor;

    printf("Czy chcesz wczytac dane z pliku? (t/n): ");
    scanf(" %c", &wybor);

    if (wybor == 't' || wybor == 'T') {
        FILE* we = fopen("we.txt", "r");
        if (we == NULL) {
            perror("Nie mozna otworzyc pliku we.txt");
            return 1;
        }
        if (fgets(infix, 1000, we) == NULL) {
            perror("Blad podczas odczytu danych z pliku");
            fclose(we);
            return 1;
        }
        fclose(we);
        infix[strcspn(infix, "\n")] = '\0'; // Usuwanie znaku nowej linii
    } else {
        printf("Podaj wyrazenie w notacji infiksowej: ");
        getchar(); // Czyszczenie bufora
        fgets(infix, 1000, stdin);
        infix[strcspn(infix, "\n")] = '\0'; // Usuwanie znaku nowej linii
    }

    inftopost(infix, postfix);

    printf("Wyrazenie w notacji postfiksowej: %s\n", postfix);

    FILE* wy = fopen("wy.txt", "w");
    if (wy == NULL) {
        perror("Nie mozna otworzyc pliku wy.txt");
        return 1;
    }
    fprintf(wy, "Wyrazenie w notacji postfiksowej: %s\n", postfix);
    fclose(wy);

    printf("Wynik zapisano do pliku wy.txt\n");

    return 0;
}

