/// Godlevskyi Andrii 
/// Zadanie 3 z laboratorium 9 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Funkcja pomocnicza do obliczania nowej przerwy
int getNextGap(int gap) {
    gap = (gap * 10) / 13; // wspolczynnik zmniejszania przerwy
    if (gap < 1) {
        return 1;
    }
    return gap;
}

// Sortowanie grzebieniowe
void combSort(int* arr, int n) {
    int gap = n;
    int swapped = 1;
    while (gap != 1 || swapped == 1) {
        gap = getNextGap(gap);
        swapped = 0;

        // porownujemy 
        for (int i = 0; i < n - gap; i++) {
            if (arr[i] > arr[i + gap]) {
                // zamiana miejscami
                int temp = arr[i];
                arr[i] = arr[i + gap];
                arr[i + gap] = temp;
                swapped = 1;
            }
        }
    }
}

// Wypisanie liczb po 10
void wypisz(int* arr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%6d", arr[i]);
        if ((i + 1) % 10 == 0) printf("\n");
    }
    if (n % 10 != 0) printf("\n");
}

// Funkcja do odczytu danych z pliku
int* odczytaj(const char* filename, int* rozmiar) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("Blad otwarcia pliku");
        return NULL;
    }
    int* data = NULL;
    int liczba, licznik = 0;
    while (fscanf(file, "%d", &liczba) == 1) {
        int* tempPtr = (int*)realloc(data, (licznik + 1) * sizeof(int));
        if (!tempPtr) {
            perror("Blad relokacji pamieci");
            free(data);
            fclose(file);
            return NULL;
        }
        data = tempPtr;
        data[licznik++] = liczba;
    }
    fclose(file);
    *rozmiar = licznik;
    return data;
}

// Funkcja do zapisu danych do pliku
void zapisz(const char* filename, int* data, int rozmiar) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        perror("Blad otwarcia pliku");
        return;
    }
    for (int i = 0; i < rozmiar; i++) {
        fprintf(file, "%6d", data[i]);
        if ((i + 1) % 10 == 0) fprintf(file, "\n");
    }
    if (rozmiar % 10 != 0) fprintf(file, "\n");
    fclose(file);
}

// Glowna funkcja
int main() {
    int* data = NULL;
    int rozmiar = 0;

    printf("Wybierz opcje:\n");
    printf("1. Generacja losowych wartosci\n");
    printf("2. Odczyt z pliku (we.txt)\n");
    printf("3. Wpisanie z klawiatury\n");
    int wybor;
    printf("Twoj wybor: ");
    scanf("%d", &wybor);

    switch (wybor) {
        case 1: {
            printf("Wpisz ilosc liczb do generacji: ");
            int n;
            scanf("%d", &n);
            int min = 1;
            int max = 999;
            data = (int*)malloc(n * sizeof(int));
            if (!data) {
                perror("Blad alokacji pamieci");
                return 1;
            }
            srand(time(0));
            for (int i = 0; i < n; i++) {
                data[i] = min + rand() % (max - min + 1);
            }
            rozmiar = n;
            break;
        }
        case 2: {
            data = odczytaj("we.txt", &rozmiar);
            if (!data) {
                return 1;
            }
            break;
        }
        case 3: {
            printf("Wpisz liczby do sortowania (aby skonczyc wpisz nie-liczbe):\n");
            int liczba;
            while (scanf("%d", &liczba) == 1) {
                int* tempPtr = (int*)realloc(data, (rozmiar + 1) * sizeof(int));
                if (!tempPtr) {
                    perror("Error reallocating memory");
                    free(data);
                    return 1;
                }
                data = tempPtr;
                data[rozmiar++] = liczba;
            }
            // wyczyszczenie bufora
            while (getchar() != '\n');
            break;
        }
        default: {
            fprintf(stderr, "Zly wybor.\n");
            return 1;
        }
    }

    // Wypisanie i zapisanie danych
    printf("Dane do sortowania:\n");
    wypisz(data, rozmiar);

    combSort(data, rozmiar);

    printf("Dane po sortowaniu:\n");
    wypisz(data, rozmiar);

    zapisz("wy.txt", data, rozmiar);

    free(data);
    return 0;
}

