#include <REGX52.H>

// Przypisanie pinow dla mastera i slavea
sbit clkMaster = P2^0;
sbit dataMaster = P2^1;
sbit clkSlave  = P2^2;
sbit dataSlave = P2^3;

// Zmienne globalne
bit flagaMaster = 1;
int delayKrotki = 2;
int delayDlugi  = 8;


volatile unsigned char liczbaMaster = 0x00;
unsigned char liczbaSlave = 0x00;

// Funkcja delay implementuje opoznienie za pomoca petli
void delay(int czas) {
    unsigned int i, j;
    for(i = 0; i < czas; i++) {
        for(j = 0; j < 255; j++) {
            // Pusta petla do opoznienia
        }
    }
}

// Obsluga przerwania INT0: zwieksza liczbe mastera
void przerwanie_INT0() interrupt 0 {
    EX0 = 0;               // Wylaczenie INT0 na czas obslugi
    liczbaMaster++;
    if(liczbaMaster == 255) {
        liczbaMaster = 0;
    }
    EX0 = 1;               // Ponowne wlaczenie INT0
    flagaMaster = 0;       // Ustawienie flagi, ze przerwanie wystapilo
}

// Funkcja wysylajaca 8 bitow wraz z bitami startu, parzystosci i stopu
// Kolejnosc: start (0),bity danych(1-8), bit parzystosci (9), bit stopu(10)
void wyslijBajt(unsigned char bajt) {
    unsigned char temp;
    unsigned char parity = 0;
    unsigned char i;
    
    // Wyslanie bitu start
    dataMaster = 0;
    delay(delayKrotki);
    delay(delayDlugi);
    clkMaster = 0;
    delay(delayDlugi);
    clkMaster = 1;
    delay(delayDlugi);
    
    // Obliczenie bitu parzystosci dla 8 bitow danych
    temp = bajt;
    for(i = 0; i < 8; i++) {
        parity ^= (temp & 0x01);
        temp >>= 1;
    }
    
    // Wysylanie 8 bitow danych (LSB pierwszy)
    {
        unsigned char bity = 8;
        while(bity--) {
            dataMaster = bajt & 0x01;
            delay(delayKrotki);
            delay(delayDlugi);
            clkMaster = 0;
            delay(delayDlugi);
            clkMaster = 1;
            delay(delayDlugi);
            bajt >>= 1;
        }
    }
    
    // Wyslanie bitu parzystosci
    dataMaster = parity;
    delay(delayKrotki);
    delay(delayDlugi);
    clkMaster = 0;
    delay(delayDlugi);
    clkMaster = 1;
    delay(delayDlugi);
    
    // Wyslanie bitu stop
    dataMaster = 1;
    delay(delayKrotki);
    delay(delayDlugi);
    clkMaster = 0;
    delay(delayDlugi);
    clkMaster = 1;
    delay(delayDlugi);
}

// Funkcja odczytujaca 8 bitow wraz z bitami startu, parzystosci i stopu
unsigned char odbierzBajt() {
    unsigned char wynik = 0;
    unsigned char pozycja = 0;
    unsigned char bityDoOdczytu = 8;
    unsigned char parityReceived = 0;
    unsigned char computedParity = 0;
    unsigned char temp;
    unsigned char i;
    
    // Odczyt bitu start - oczekiwanie na impuls zegara
    while(clkSlave == 1) {
        delay(delayKrotki);
    }
    // Sprawdzenie bitu start (musi byc zerowy)
    if(dataSlave != 0) {
    }
    // Oczekiwanie na powrot zegara do stanu wysokiego
    while(clkSlave == 0) {
        delay(delayKrotki);
    }
    
    // Odczyt 8 bitow danych
    while(bityDoOdczytu--) {
        while(clkSlave == 1) {
            delay(delayKrotki);
        }
        if(dataSlave) {
            wynik |= (1 << pozycja);
        }
        while(clkSlave == 0) {
            delay(delayKrotki);
        }
        pozycja++;
    }
    
    // Odczyt bitu parzystosci
    while(clkSlave == 1) {
        delay(delayKrotki);
    }
    if(dataSlave) {
        parityReceived = 1;
    }
    while(clkSlave == 0) {
        delay(delayKrotki);
    }
    
    // Obliczenie parzystosci na podstawie odebranych danych
    computedParity = 0;
    temp = wynik;
    for(i = 0; i < 8; i++) {
        computedParity ^= (temp & 0x01);
        temp >>= 1;
    }
    // Sprawdzenie bitu parzystosci
    if(computedParity != parityReceived) {
    }
    
    // Odczyt bitu stop (musi byc jedynka)
    while(clkSlave == 1) {
        delay(delayKrotki);
    }
    if(dataSlave != 1) {
    }
    while(clkSlave == 0) {
        delay(delayKrotki);
    }
    
    return wynik;
}

// Inicjalizacja przerwan INT0
void inicjujPrzerwania() {
    liczbaMaster = 0;
    IT0 = 1;   // INT0 uruchamiany na zboczu opadajacym
    EX0 = 1;   // Wlaczenie INT0
    EA = 1;    // Wlaczenie wszystkich przerwan
}

// Funkcja glowna dziala w trybie MASTER lub SLAVE w zaleznosci od stanu P0_0
void main() {
    inicjujPrzerwania();
    P1 = 0;
    clkMaster = 1;
    dataMaster = 1;
    
    //MASTER gdy P0_0 jest wysoki
    while(P0_0 == 1) {
        while(flagaMaster) {
            delay(delayKrotki);
        }
        P1 = liczbaMaster;
        wyslijBajt(liczbaMaster);
        flagaMaster = 1;
    }
    
    //Tryb SLAVE gdy P0_0 jest niski
    while(P0_0 == 0) {
        while(clkSlave == 1) {
            delay(delayKrotki);
        }
        liczbaSlave = odbierzBajt();
        P1 = liczbaSlave;
    }
}
