#include <REGX52.H>

bit bM = 1;          // Flaga do skanowania klawiatury (zerowana w przerwaniu)
unsigned char keyCode; // Zmienna globalna przechowujaca zdekodowany znak

void init()
{
	IT0 = 1;	//INT0 aktywne zero
	EX0 = 1;	//Wlaczenia INT0
	ES = 1;		//Wlaczenie przerwan od portu szeregowego
	EA = 1;		//Wlaczenie wszstkich przerwan
}

void int0ISR() interrupt 0
{
    EX0 = 0; // Tymczasowe wylaczenie przerwania 
    bM = 0;  // Ustawienie flagi bM na 0 - przerywa skanowanie
    EX0 = 1; // Ponowne wlaczenie przerwania INT0
}

 void scanKeyboard()
{
    while(bM)  // Dopoki nie nastapi przerwanie INT0
    {
        switch(P2)
        {
            case 0xEF: P2 = 0xDF; break;
            case 0xDF: P2 = 0xBF; break;
            case 0xBF: P2 = 0x7F; break;
            case 0x7F: P2 = 0xEF; break;
            default:   P2 = 0xEF; break; // Stan poczatkowy na wypadek nieznanych wartosci
        }
    }
}

unsigned char decodeKey()
{
    switch(P2)
    {
        case 0xEE: return 0x30; // '0'
        case 0xDE: return 0x31; // '1'
        case 0xBE: return 0x32; // '2'
        case 0x7E: return 0x33; // '3'
        case 0xED: return 0x34; // '4'
        case 0xDD: return 0x35; // '5'
        case 0xBD: return 0x36; // '6'
        case 0x7D: return 0x37; // '7'
        case 0xEB: return 0x38; // '8'
        case 0xDB: return 0x39; // '9'
        case 0xBB: return 0x41; // 'A'
        case 0x7B: return 0x42; // 'B'
        case 0xE7: return 0x43; // 'C'
        case 0xD7: return 0x44; // 'D'
        case 0xB7: return 0x45; // 'E'
        case 0x77: return 0x46; // 'F'
        default:   return 0xFF; // Nie rozpoznano klawisza
    }
}


void displayKey(unsigned char key)
{
    P1 = key;  //Przypisanie kodu ASCII do portu
}													  

void main()
{
    P1 = 0xFF; // Domyslnie nic nie wyswietlamy 
    P2 = 0xEF; // Ustawienie poczatkowe portu P2
    init();    // Inicjalizacja przerwan

    // Dopoki pin P0.0 ma stan wysoki
    while(P0_0 == 1)
    {
        // Skanowanie klawiatury az do wcisniecia klawiszy
        scanKeyboard();
        
        // Dekodowanie aktualnego stanu portu P2 na kod ASCII
        keyCode = decodeKey();
        
        // Wyswietlanie zdekodowanego znaku na porcie P1
        displayKey(keyCode);
        
        // Ponowne wejscie do trybu skanowania
        bM = 1;
    }

    // Petla zatrzymujaca
    while(P0_0 == 0)
    {
   
    }
}