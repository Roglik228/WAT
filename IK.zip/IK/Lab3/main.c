#include <REGX52.H>

//Definicje linii
sbit CLK_slave  = P0^4;   // Linia zegara odbierana przez slave
sbit ACK_slave  = P0^5;   // Potwierdzenie od slave
sbit CLK_master = P0^6;   // Linia zegara generowana przez master
sbit ACK_master = P0^7;   // Potwierdzenie od master

bit bM          = 1;      // Flaga mastera: 1 = gotowosc, 0 = nowa dana
int dt          = 10;     // Podstawa opoznienia programowego
int tt          = 100;

volatile unsigned char liczbaM = 0x00;  // Licznik mastera 

unsigned char bajt             = 0x00;  // Bufor pomocniczy

//Opoznienie programowe 
void czekaj(int i)
{
    unsigned int k, l, m;
    for (l = 0; l < i; l++)
    {
        k = 500;
        m = 1000;
        k = m * l;  
    }
}

//Obsluga przerwania  INT0
void liczInt0() interrupt 0
{
    EX0 = 0;               // Blokada kolejnych przerwan INT0
    liczbaM++;             // Inkrementacja licznika
    if (liczbaM == 255)
        liczbaM = 0;
    EX0 = 1;               
    bM = 0;                // Zgloszenie, ze pojawila sie nowa dana
}

// Wyslanie bajtu danych
void zapiszBajt(unsigned char bajt)
{
    while (ACK_master == 0) czekaj(1);  // Czekaj, az slave gotowy
    CLK_master = 1;                     // Poczatkowy impuls zegarowy
    czekaj(1);

    P2 = bajt;                          // Umiesc dane na magistrali
    czekaj(1);

    CLK_master = 0;                    
    while (ACK_master == 1) czekaj(1);  // Czekaj na ACK w stanie niskim
    CLK_master = 1;                     // Koniec impulsu
    while (ACK_master == 0) czekaj(1);  // Czekaj na zwolnienie ACK

    P2 = 0xFF;                          // Zwolnienie portu danych
}

void initInt0()
{
    liczbaM = 0;
    IT0 = 1;    // INT0 aktywne stanem niskim
    EX0 = 1;    // Wlaczenie INT0
    EA  = 1;    // Globalne odblokowanie przerwan
}

void main()
{
    initInt0();
    P1 = 0;
    ACK_slave = 1;  // Domyslnie wysoki poziom
    CLK_master = 1; // Stan spoczynkowy zegara

    //Master
    while (P0_0 == 1)
    {
        while (bM) { czekaj(dt); }  // Oczekiwanie na flage nowej danej

        P1 = liczbaM;               // Wyswietlenie wartosci na diodach
        zapiszBajt(liczbaM);        // Wyslanie do slave
        bM = 1;                     // Ponowna gotowosc
    }

    //Slave
    while (P0_0 == 0)
    {
        while (CLK_slave == 1) { czekaj(dt); }  // Czekaj na zbocze zegara
        ACK_slave = 0;                         // Zglos ACK nisko
        P1 = P2;                               // Odczytaj bajt na PORT1
        czekaj(1);
        ACK_slave = 1;                         // Zwolnij ACK
    }
}
